import { TableState } from './types';
import { mergeStates } from './CRDTMerge';

/**
 * OFFLINE STORE (IndexedDB Wrapper)
 * Manages local persistence for table states and order logs.
 */
class OfflineStore {
  private dbName = 'saito_pos_offline';
  private version = 1;

  async initDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('tables')) {
          db.createObjectStore('tables', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('logs')) {
          db.createObjectStore('logs', { keyPath: 'timestamp' });
        }
        if (!db.objectStoreNames.contains('orders')) {
          db.createObjectStore('orders', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('order_items')) {
          db.createObjectStore('order_items', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('outbox')) {
          const outbox = db.createObjectStore('outbox', { keyPath: 'id', autoIncrement: true });
          outbox.createIndex('table', 'table', { unique: false });
          outbox.createIndex('synced', 'synced', { unique: false });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async saveTableState(state: TableState): Promise<void> {
    const db = await this.initDB();
    const tx = db.transaction('tables', 'readwrite');
    const store = tx.objectStore('tables');

    const existing: TableState | undefined = await new Promise((res) => {
      const req = store.get(state.id);
      req.onsuccess = () => res(req.result);
    });

    const finalState = existing ? mergeStates(existing, state) : state;
    store.put(finalState);

    return new Promise((res) => {
      tx.oncomplete = () => res();
    });
  }

  async getAllTables(): Promise<TableState[]> {
    const db = await this.initDB();
    const tx = db.transaction('tables', 'readonly');
    const store = tx.objectStore('tables');
    const request = store.getAll();

    return new Promise((res) => {
      request.onsuccess = () => res(request.result);
    });
  }

  async pushToLog(action: any): Promise<void> {
    const db = await this.initDB();
    const tx = db.transaction('logs', 'readwrite');
    const store = tx.objectStore('logs');
    store.put({
      ...action,
      timestamp: Date.now(),
      synced: false,
    });
    return new Promise((res) => { tx.oncomplete = () => res(); });
  }

  async getUnsyncedLogs(): Promise<any[]> {
    const db = await this.initDB();
    const tx = db.transaction('logs', 'readonly');
    const store = tx.objectStore('logs');
    const request = store.getAll();

    return new Promise((res) => {
      request.onsuccess = () => {
        const allLogs = request.result || [];
        res(allLogs.filter((l: any) => !l.synced));
      };
    });
  }

  async markAsSynced(timestamp: number): Promise<void> {
    const db = await this.initDB();
    const tx = db.transaction('logs', 'readwrite');
    const store = tx.objectStore('logs');

    const request = store.get(timestamp);
    request.onsuccess = () => {
      const data = request.result;
      if (data) {
        data.synced = true;
        store.put(data);
      }
    };
    return new Promise((res) => { tx.oncomplete = () => res(); });
  }

  async saveOrder(order: any): Promise<void> {
    const db = await this.initDB();
    const tx = db.transaction('orders', 'readwrite');
    const store = tx.objectStore('orders');
    store.put(order);
    return new Promise((res) => { tx.oncomplete = () => res(); });
  }

  async getAllOrders(): Promise<any[]> {
    const db = await this.initDB();
    const tx = db.transaction('orders', 'readonly');
    const store = tx.objectStore('orders');
    const request = store.getAll();
    return new Promise((res) => { request.onsuccess = () => res(request.result || []); });
  }

  async saveOrderItem(item: any): Promise<void> {
    const db = await this.initDB();
    const tx = db.transaction('order_items', 'readwrite');
    const store = tx.objectStore('order_items');
    store.put(item);
    return new Promise((res) => { tx.oncomplete = () => res(); });
  }

  async getAllOrderItems(): Promise<any[]> {
    const db = await this.initDB();
    const tx = db.transaction('order_items', 'readonly');
    const store = tx.objectStore('order_items');
    const request = store.getAll();
    return new Promise((res) => { request.onsuccess = () => res(request.result || []); });
  }

  async pushToOutbox(action: any): Promise<void> {
    const db = await this.initDB();
    const tx = db.transaction('outbox', 'readwrite');
    const store = tx.objectStore('outbox');
    store.put({ ...action, synced: false, created_at: Date.now() });
    return new Promise((res) => { tx.oncomplete = () => res(); });
  }

  async getOutbox(): Promise<any[]> {
    const db = await this.initDB();
    const tx = db.transaction('outbox', 'readonly');
    const store = tx.objectStore('outbox');
    const request = store.getAll();
    return new Promise((res) => { request.onsuccess = () => res(request.result || []); });
  }

  async markOutboxSynced(id: number): Promise<void> {
    const db = await this.initDB();
    const tx = db.transaction('outbox', 'readwrite');
    const store = tx.objectStore('outbox');
    const request = store.get(id);
    request.onsuccess = () => {
      const data = request.result;
      if (data) {
        data.synced = true;
        store.put(data);
      }
    };
    return new Promise((res) => { tx.oncomplete = () => res(); });
  }

  async clearOutbox(): Promise<void> {
    const db = await this.initDB();
    const tx = db.transaction('outbox', 'readwrite');
    const store = tx.objectStore('outbox');
    store.clear();
    return new Promise((res) => { tx.oncomplete = () => res(); });
  }
}

export const localStore = new OfflineStore();
