/**
 * Consolidated table status definitions and transition rules.
 * Single source of truth for POS/UI table display states and order statuses.
 */

export enum TableStatus {
  EMPTY = 'empty',
  RESERVED = 'reserved',
  OCCUPIED = 'occupied',
  MERGED = 'merged',
  PAYMENT_PENDING = 'payment_pending',
  CLEANING = 'cleaning',
  SEATED = 'seated',
  ORDERING = 'ordering',
  IN_KITCHEN = 'in_kitchen',
  DINING = 'dining',
  PAID = 'paid',
  OUT_OF_SERVICE = 'out_of_service',
}

export type OrderStatus = 'new' | 'confirmed' | 'paid' | 'cancelled' | 'checked_in' | 'completed' | 'no_show' | 'archived' | 'pending';

export type KitchenStatus = 'pending' | 'preparing' | 'ready' | null | undefined;

const VALID_TRANSITIONS: Record<TableStatus, TableStatus[]> = {
  [TableStatus.EMPTY]: [TableStatus.RESERVED, TableStatus.OCCUPIED, TableStatus.SEATED],
  [TableStatus.RESERVED]: [TableStatus.OCCUPIED, TableStatus.EMPTY, TableStatus.SEATED],
  [TableStatus.OCCUPIED]: [TableStatus.MERGED, TableStatus.PAYMENT_PENDING, TableStatus.EMPTY, TableStatus.DINING, TableStatus.PAID],
  [TableStatus.MERGED]: [TableStatus.OCCUPIED, TableStatus.EMPTY],
  [TableStatus.PAYMENT_PENDING]: [TableStatus.EMPTY, TableStatus.OCCUPIED, TableStatus.CLEANING, TableStatus.PAID],
  [TableStatus.CLEANING]: [TableStatus.EMPTY, TableStatus.OCCUPIED],
  [TableStatus.SEATED]: [TableStatus.ORDERING, TableStatus.EMPTY],
  [TableStatus.ORDERING]: [TableStatus.IN_KITCHEN, TableStatus.OCCUPIED, TableStatus.EMPTY],
  [TableStatus.IN_KITCHEN]: [TableStatus.DINING, TableStatus.OCCUPIED, TableStatus.EMPTY],
  [TableStatus.DINING]: [TableStatus.PAYMENT_PENDING, TableStatus.OCCUPIED, TableStatus.EMPTY],
  [TableStatus.PAID]: [TableStatus.CLEANING, TableStatus.EMPTY],
  [TableStatus.OUT_OF_SERVICE]: [TableStatus.EMPTY, TableStatus.CLEANING],
};

export function isValidTableTransition(from: TableStatus, to: TableStatus): boolean {
  if (from === to) return true;
  return VALID_TRANSITIONS[from]?.includes(to) || false;
}

export interface TableComputeInput {
  floorStatus: string | null | undefined;
  activeOrders: unknown[];
  mergedIntoTable?: number | null | undefined;
  reservation?: { id: string } | null | undefined;
}

export function computeTableStatus(input: TableComputeInput): TableStatus {
  const { floorStatus, activeOrders, mergedIntoTable, reservation } = input;

  if (mergedIntoTable != null) return TableStatus.MERGED;
  if (reservation != null || floorStatus === 'reserved') return TableStatus.RESERVED;
  if (activeOrders.length > 0) return TableStatus.OCCUPIED;
  return TableStatus.EMPTY;
}