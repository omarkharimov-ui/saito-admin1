'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Phone, Clock, Users, Star, ChevronRight, Pencil, Printer, UserX, Merge, Move, Ban, CheckCircle } from 'lucide-react';
import { toast } from '@/lib/toast';
import { supabase } from '@/lib/supabase';
import BottomSheet from '@/components/ui/BottomSheet';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface ReservedTableModalProps {
  open: boolean;
  onClose: () => void;
  table: {
    table_number: number;
    reservation_id: string | null;
    reservation_name: string | null;
    reservation_phone: string | null;
    reservation_time: string | null;
    guest_count: number | null;
    status: string;
    reservation_status_snapshot?: string | null;
    is_vip?: boolean | null;
  } | null;
  onGuestArrived: () => void;
  onEditReservation: () => void;
  onMoveTable?: () => void;
  onMergeTable?: () => void;
  onCancelReservation?: () => void;
  onMarkNoShow?: () => void;
  onPrintReservation?: () => void;
}

export default function ReservedTableModal({
  open,
  onClose,
  table,
  onGuestArrived,
  onEditReservation,
  onMoveTable,
  onMergeTable,
  onCancelReservation,
  onMarkNoShow,
  onPrintReservation,
}: ReservedTableModalProps) {
  const { t } = useLanguage();
  const [showBottomSheet, setShowBottomSheet] = useState(false);

  if (!table) return null;

  const maskPhone = (phone: string | null) => {
    if (!phone) return '';
    if (phone.length <= 4) return phone;
    return phone.slice(0, 3) + '•••••••';
  };

  const reservation = table.reservation_id ? table : null;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-center p-4 pointer-events-none"
        >
          <div className="pointer-events-auto w-full max-w-md bg-white text-black rounded-2xl shadow-2xl border border-white/20 p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-amber-600 mb-1">Rezervasyon</p>
                <p className="text-sm font-bold">Masa {table.table_number}</p>
                {table.reservation_name && (
                  <p className="text-xs text-zinc-500 mt-0.5">{table.reservation_name}</p>
                )}
              </div>
              <div className="flex items-center gap-2">
                {table.is_vip && (
                  <span className="px-2 py-1 rounded-lg bg-amber-500 text-white text-[9px] font-black uppercase tracking-wider">VIP</span>
                )}
                <button onClick={onClose} className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-500 hover:bg-zinc-200 transition-all">
                  <X size={16} />
                </button>
              </div>
            </div>

            <div className="space-y-2 mb-5">
              {table.reservation_phone && (
                <div className="flex items-center gap-2 text-xs text-zinc-600">
                  <Phone size={14} className="text-zinc-400" />
                  <span className="font-mono">{maskPhone(table.reservation_phone)}</span>
                </div>
              )}
              {table.reservation_time && (
                <div className="flex items-center gap-2 text-xs text-zinc-600">
                  <Clock size={14} className="text-zinc-400" />
                  <span>{table.reservation_time}</span>
                </div>
              )}
              {table.guest_count && (
                <div className="flex items-center gap-2 text-xs text-zinc-600">
                  <Users size={14} className="text-zinc-400" />
                  <span>{table.guest_count} nəfər</span>
                </div>
              )}
            </div>

            <div className="flex gap-2 mb-3">
              <button
                onClick={onGuestArrived}
                className="flex-1 py-4 rounded-2xl bg-amber-500 text-white text-xs font-black hover:bg-amber-600 transition-all flex items-center justify-center gap-2"
              >
                <CheckCircle size={16} />
                QONAQ GƏLDİ
              </button>
              <button
                onClick={onEditReservation}
                className="px-4 py-4 rounded-2xl border border-zinc-200 text-zinc-600 text-xs font-black hover:bg-zinc-50 transition-all"
                title="Redaktə"
              >
                <Pencil size={16} />
              </button>
              <button
                onClick={() => setShowBottomSheet(true)}
                className="px-4 py-4 rounded-2xl border border-zinc-200 text-zinc-600 text-xs font-black hover:bg-zinc-50 transition-all"
                title="Ətraflı"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>

          <BottomSheet
            open={showBottomSheet}
            onClose={() => setShowBottomSheet(false)}
          >
            <div className="p-4">
              <h3 className="text-lg font-black text-white mb-4">Rezervasiya Əməliyyatları</h3>
              <div className="space-y-2">
              <button
                onClick={() => { setShowBottomSheet(false); onMoveTable?.(); }}
                className="w-full flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all"
              >
                <Move size={20} className="text-blue-400" />
                <div className="text-left">
                  <p className="text-sm font-bold text-white">Masa Dəyiş</p>
                  <p className="text-[10px] text-white/40">Başqa boş masaya köçür</p>
                </div>
              </button>
              <button
                onClick={() => { setShowBottomSheet(false); onMergeTable?.(); }}
                className="w-full flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all"
              >
                <Merge size={20} className="text-emerald-400" />
                <div className="text-left">
                  <p className="text-sm font-bold text-white">Masa Birləşdir</p>
                  <p className="text-[10px] text-white/40">Yeni masa əlavə et</p>
                </div>
              </button>
              <button
                onClick={() => { setShowBottomSheet(false); onPrintReservation?.(); }}
                className="w-full flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all"
              >
                <Printer size={20} className="text-zinc-400" />
                <div className="text-left">
                  <p className="text-sm font-bold text-white">Çap Et</p>
                  <p className="text-[10px] text-white/40">Rezervasiya bileti</p>
                </div>
              </button>
              <button
                onClick={() => { setShowBottomSheet(false); onMarkNoShow?.(); }}
                className="w-full flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all"
              >
                <UserX size={20} className="text-rose-400" />
                <div className="text-left">
                  <p className="text-sm font-bold text-white">No Show</p>
                  <p className="text-[10px] text-white/40">Qonaq gəlmədi</p>
                </div>
              </button>
              <button
                onClick={() => { setShowBottomSheet(false); onCancelReservation?.(); }}
                className="w-full flex items-center gap-3 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 transition-all"
              >
                <Ban size={20} className="text-rose-500" />
                <div className="text-left">
                  <p className="text-sm font-bold text-rose-400">Ləğv Et</p>
                  <p className="text-[10px] text-rose-400/60">Rezervasiyanı ləğv et</p>
                </div>
              </button>
            </div>
          </BottomSheet>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
