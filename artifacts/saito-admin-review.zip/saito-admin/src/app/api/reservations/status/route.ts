import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/api-auth';
import { requireActiveShift } from '@/lib/shiftLock';

function svc() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
  return { url, headers: { 'apikey': key, 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' } };
}

const VALID_STATUS_TRANSITIONS: Record<string, string[]> = {
  pending: ['confirmed', 'cancelled', 'expired'],
  confirmed: ['waiting', 'checked_in', 'cancelled', 'no_show', 'expired'],
  waiting: ['checked_in', 'cancelled', 'no_show'],
  checked_in: ['completed', 'cancelled'],
  completed: ['archived'],
  cancelled: ['pending'],
  no_show: ['pending'],
  expired: ['pending'],
  archived: ['pending'],
  waiting_list: ['waiting', 'checked_in', 'cancelled', 'no_show'],
};

function isValidTransition(from: string, to: string): boolean {
  if (from === to) return true;
  return VALID_STATUS_TRANSITIONS[from]?.includes(to) ?? false;
}

const TABLE_STATUS_MAP: Record<string, string | null> = {
  confirmed: 'reserved',
  waiting: 'waiting',
  checked_in: 'occupied',
  completed: 'empty',
  cancelled: 'empty',
  no_show: 'empty',
  expired: 'empty',
};

export async function POST(request: NextRequest) {
  try {
    const auth = await requireAuth(['cashier', 'admin', 'superadmin']);
    if (!auth.authenticated) return auth;

    const shiftCheck = await requireActiveShift();
    if (!shiftCheck.ok) {
      return NextResponse.json({ error: shiftCheck.error }, { status: 403 });
    }

    const { id, reservation_id, status, notes } = await request.json();
    const reservationId = id || reservation_id;

    if (!reservationId || !status) {
      return NextResponse.json({ error: 'id and status are required' }, { status: 400 });
    }

    const s = svc();

    // 1. Fetch current reservation
    const resRes = await fetch(`${s.url}/rest/v1/reservations?select=*&id=eq.${reservationId}`, { headers: s.headers });
    const resData: any[] = await resRes.json();
    const current = resData?.[0];

    if (!current) {
      return NextResponse.json({ error: 'Reservation not found' }, { status: 404 });
    }

    // 2. Validate transition
    if (!isValidTransition(current.status, status)) {
      return NextResponse.json({
        error: `Cannot transition from '${current.status}' to '${status}'`,
      }, { status: 409 });
    }

    // 3. Check for active orders before cancelling/no_show/expired
    if (status === 'cancelled' || status === 'no_show' || status === 'expired') {
      const ordersRes = await fetch(
        `${s.url}/rest/v1/orders?select=id,status&reservation_id=eq.${current.id}&status=neq.paid&status=neq.cancelled`,
        { headers: s.headers }
      );
      const activeOrders: any[] = await ordersRes.json();
      if (activeOrders.length > 0) {
        for (const order of activeOrders) {
          await fetch(`${s.url}/rest/v1/orders?id=eq.${order.id}`, {
            method: 'PATCH',
            headers: s.headers,
            body: JSON.stringify({ status: 'cancelled', updated_at: new Date().toISOString() }),
          });
        }
      }

      // 3b. Cancel orphan draft orders with kitchen_status = 'reserved'
      const draftRes = await fetch(
        `${s.url}/rest/v1/orders?select=id&reservation_id=eq.${current.id}&is_draft=eq.true&kitchen_status=eq.reserved`,
        { headers: s.headers }
      );
      const draftOrders: any[] = await draftRes.json();
      if (Array.isArray(draftOrders) && draftOrders.length > 0) {
        const draftIds = draftOrders.map(o => o.id).filter(Boolean);
        const CHUNK = 20;
        for (let i = 0; i < draftIds.length; i += CHUNK) {
          const chunk = draftIds.slice(i, i + CHUNK);
          const orFilter = chunk.map(id => `id.eq.${id}`).join(',');
          await fetch(`${s.url}/rest/v1/orders?or=(${orFilter})`, {
            method: 'PATCH',
            headers: s.headers,
            body: JSON.stringify({ status: 'cancelled', updated_at: new Date().toISOString() }),
          });
        }
      }
    }

    // 4. Handle guest arrival: atomic flow for pending reservations
    if (status === 'checked_in' && current.status === 'pending') {
      const tableIdsJson = current.table_ids ? (typeof current.table_ids === 'string' ? current.table_ids : JSON.stringify(current.table_ids)) : '[]';
      const rpcRes = await fetch(`${s.url}/rest/v1/rpc/confirm_and_checkin_atomic`, {
        method: 'POST',
        headers: s.headers,
        body: JSON.stringify({
          p_reservation_id: reservationId,
          p_table_ids: JSON.parse(tableIdsJson),
          p_user_id: (auth.user?.id || null) as any,
        }),
      });
      const rpcData = await rpcRes.json();
      if (!rpcRes.ok || rpcData?.error) {
        return NextResponse.json({ error: rpcData?.error || 'Confirm & Check In failed' }, { status: 400 });
      }
    }
    else if (status === 'checked_in' && current.status === 'confirmed') {
      // For confirmed reservations, activate table and create order
      if (current.table_ids) {
        const tableIds = typeof current.table_ids === 'string' ? JSON.parse(current.table_ids) : current.table_ids;
        for (const tId of tableIds) {
          await fetch(`${s.url}/rest/v1/table_floors?id=eq.${tId}`, {
            method: 'PATCH',
            headers: s.headers,
            body: JSON.stringify({
              status: 'occupied',
              reservation_id: null,
              reservation_name: null,
              reservation_phone: null,
              reservation_time: null,
              guest_count: current.guests ?? null,
            }),
          });
        }
      }

      // Create order now (only on check-in, not on confirm)
      const tableIdsForOrder = current.table_ids ? (typeof current.table_ids === 'string' ? JSON.parse(current.table_ids) : current.table_ids) : [];
      if (tableIdsForOrder.length > 0) {
        const tblRes = await fetch(`${s.url}/rest/v1/table_floors?id=eq.${tableIdsForOrder[0]}&select=table_number`, { headers: s.headers });
        const tblData = await tblRes.json();
        const resolvedTableNumber = (Array.isArray(tblData) ? tblData[0] : null)?.table_number;

        if (resolvedTableNumber) {
          const orderPayload: Record<string, any> = {
            table_number: resolvedTableNumber,
            reservation_id: current.id,
            status: 'confirmed',
            kitchen_status: 'pending',
            is_draft: false,
            guest_count: current.guests ?? 2,
            total_amount: current.pre_order_total || 0,
            customer_id: current.customer_id || null,
            customer_name: current.name || current.customer_name || null,
            customer_note: current.note || null,
            created_at: new Date().toISOString(),
            version: 1,
          };
          const createRes = await fetch(`${s.url}/rest/v1/orders`, {
            method: 'POST',
            headers: { ...s.headers, 'Prefer': 'return=representation' },
            body: JSON.stringify(orderPayload),
          });
          if (createRes.ok) {
            const created = await createRes.json();
            const newOrderId = Array.isArray(created) ? created[0]?.id : created?.id;

            // Insert pre-order items if any
            const preItems = current.pre_order_items || [];
            if (Array.isArray(preItems) && preItems.length > 0 && newOrderId) {
              for (const item of preItems) {
                await fetch(`${s.url}/rest/v1/order_items`, {
                  method: 'POST',
                  headers: s.headers,
                  body: JSON.stringify({
                    order_id: newOrderId,
                    product_id: item.product_id,
                    product_name: item.product_name,
                    quantity: item.quantity,
                    unit_price: item.unit_price,
                    total_price: (item.unit_price || 0) * (item.quantity || 1),
                    modifiers: item.modifiers || [],
                    special_notes: item.special_notes || '',
                    kitchen_status: 'pending',
                    price_snapshot: {
                      unit_price: item.unit_price || 0,
                      quantity: item.quantity,
                      total_price: (item.unit_price || 0) * (item.quantity || 1),
                      campaign_id: null,
                      campaign_discount: 0,
                      tax: 0,
                      currency: 'AZN',
                      snapshot_at: new Date().toISOString(),
                    },
                  }),
                });
              }
            }

            // Decouple: clear pre-order from reservation after copying to order
            await fetch(`${s.url}/rest/v1/reservations?id=eq.${reservationId}`, {
              method: 'PATCH',
              headers: s.headers,
              body: JSON.stringify({
                pre_order_items: '[]',
                pre_order_total: 0,
              }),
            });
          }
        }
      }
    }

    // 5. Update reservation
    const updatePayload: Record<string, any> = { status };
    if (notes) updatePayload.note = notes;
    if (status === 'checked_in') updatePayload.checked_in_at = new Date().toISOString();
    if (status === 'completed') updatePayload.completed_at = new Date().toISOString();

    await fetch(`${s.url}/rest/v1/reservations?id=eq.${reservationId}`, {
      method: 'PATCH',
      headers: s.headers,
      body: JSON.stringify(updatePayload),
    });

    // 7. Audit log
    const auditTable = 'audit_logs';
    const auditBody = {
      table_name: 'reservations',
      record_id: reservationId,
      action: `status_change:${current.status}→${status}`,
      old_data: { status: current.status },
      new_data: { status, notes },
      performed_by: auth.user?.id || null,
      created_at: new Date().toISOString(),
    };
    const auditRes = await fetch(`${s.url}/rest/v1/${auditTable}`, {
      method: 'POST',
      headers: s.headers,
      body: JSON.stringify(auditBody),
    });
    if (!auditRes.ok) {
      const auditText = await auditRes.text();
      // Try with singular name if plural fails
      if (auditRes.status === 404) {
        await fetch(`${s.url}/rest/v1/audit_log`, {
          method: 'POST',
          headers: s.headers,
          body: JSON.stringify(auditBody),
        });
      }
    }

    // 8. If cancelled/no_show/expired with pre-order, cancel kitchen schedule
    if ((status === 'cancelled' || status === 'no_show' || status === 'expired') && current.kitchen_scheduled_at) {
      await fetch(`${s.url}/rest/v1/kitchen_schedule?reservation_id=eq.${reservationId}`, {
        method: 'PATCH',
        headers: s.headers,
        body: JSON.stringify({ status: 'cancelled' }),
      });
    }

    return NextResponse.json({ success: true, status });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
