'use client';

import { useState, useEffect, useCallback, useMemo, useRef, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import toast, { useToaster } from '@/lib/toast';
import { supabase } from '@/lib/supabase';
import { createRealtimeChannel, removeRealtimeChannel } from '@/lib/realtime';
import { localStore } from '@/lib/sync/OfflineStore';
import { Clock, ChefHat, Utensils, AlertTriangle, BarChart2, Volume2, VolumeX, FlameKindling, SendHorizonal, LogOut, GitMerge, LayoutGrid, Map as MapIcon, Sun, Moon, Scissors, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { useTheme } from '@/lib/theme/ThemeContext';
import { WelcomeScreen } from '@/components/WelcomeScreen';
import { KitchenAIScheduler } from './components/KitchenAIScheduler';
import { UpcomingReservations } from './components/UpcomingReservations';
import { CountdownTimer } from './components/CountdownTimer';
import { TableMapView } from './components/TableMapView';
import { az } from '@/lib/i18n/locales/az';
import { en } from '@/lib/i18n/locales/en';
import { ru } from '@/lib/i18n/locales/ru';

function KitchenToaster() {
  const { toasts, handlers } = useToaster({ duration: 2500 });
  const { startPause, endPause } = handlers;
  return (
    <div
      onMouseEnter={startPause}
      onMouseLeave={endPause}
      style={{ position: 'fixed', top: 16, right: 16, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end', pointerEvents: 'none' }}
    >
      <AnimatePresence>
        {toasts.filter(t => t.visible).map(t => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, x: 80, scale: 0.92 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 340, scale: 0.92 }}
            transition={{ type: 'spring', stiffness: 380, damping: 32 }}
            drag="x"
            dragConstraints={{ left: 0, right: 340 }}
            dragElastic={0.08}
            onDragEnd={(_e, info) => { if (info.offset.x > 60 || info.velocity.x > 250) toast.dismiss(t.id); }}
            onClick={() => toast.dismiss(t.id)}
            style={{
              pointerEvents: 'auto',
              cursor: 'pointer',
              minWidth: 200,
              maxWidth: 320,
              padding: '10px 14px',
              borderRadius: 14,
              fontSize: 13,
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              boxShadow: '0 4px 24px rgba(0,0,0,0.5)',
              userSelect: 'none',
              ...(typeof t.style === 'object' ? t.style : {}),
            }}
          >
            <span style={{ flex: 1 }}>
              {typeof t.message === 'function'
                ? (t.message as (t: any) => React.ReactNode)(t)
                : t.message as React.ReactNode}
            </span>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

// ─── Types ────────────────────────────────────────────────────────────────────

interface OrderItem {
  id: string;
  product_name: string;
  product_id?: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  image_url?: string;
  kitchen_status?: 'pending' | 'ready';
  orderedQuantity: number;
  preparedQuantity: number;
  created_at?: string;
  is_on_hold?: boolean;
  course?: string;
  hold_until?: string | null;
  printer_route?: string | null;
  station?: string;
}

interface Order {
  id: string;
  table_number: number;
  items: OrderItem[];
  total_amount: number;
  created_at: string;
  kitchen_status: string;
  kitchen_accepted_at?: string | null;
  kitchen_ready_at?: string | null;
  void_reason?: string | null;
  customer_note?: string;
  status: 'new' | 'confirmed' | 'paid' | 'cancelled' | string;
  is_rush?: boolean;
  is_draft?: boolean;
  merged_from_tables?: number[];
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const translations = { az, en, ru };

function timerBase(order: { created_at: string; kitchen_accepted_at?: string | null }): string {
  return order.kitchen_accepted_at || order.created_at;
}

function formatTime(createdAt: string, t: any): string {
  const diff = Math.floor((Date.now() - new Date(createdAt).getTime()) / 60000);
  if (diff < 1) return t.time_now || 'İndi';
  if (diff < 60) return `${diff} ${t.time_min || 'dəq'}`;
  return `${Math.floor(diff / 60)} ${t.time_hour || 'saat'}`;
}

function elapsedMinutes(createdAt: string): number {
  return Math.floor((Date.now() - new Date(createdAt).getTime()) / 60000);
}

function isAllItemsReady(order: Order): boolean {
  return order.items.length > 0 && order.items.every(it => it.preparedQuantity >= it.orderedQuantity);
}

function isDelayed(order: Order, threshold = 15): boolean {
  if (!order.kitchen_accepted_at) return false;
  return elapsedMinutes(order.kitchen_accepted_at) >= threshold && !isAllItemsReady(order);
}

function priorityWeight(order: Order): number {
  if (order.is_rush) return 0;
  if (isDelayed(order)) return 1;
  if (!['preparing', 'ready', 'completed'].includes(order.kitchen_status)) return 2;
  return 3;
}

function mapRawOrder(o: any, lang = 'az'): Order {
  const items: OrderItem[] = (o.order_items || []).map((i: any) => {
    const orderedQuantity = Number(i.quantity) || 0;
    const preparedQuantity = Number(i.prepared_quantity) || 0;
    const prod = Array.isArray(i.products) ? i.products[0] : i.products;
    const translations = prod?.translations as Record<string, {name?: string}> | null | undefined;
    const localName = translations?.[lang.toLowerCase()]?.name || translations?.['az']?.name || i.product_name;
    return {
      id: i.id,
      product_id: i.product_id,
      product_name: localName,
      quantity: orderedQuantity,
      unit_price: i.unit_price || 0,
      total_price: i.total_price,
      kitchen_status: (i.kitchen_status as 'pending' | 'ready') || 'pending',
      orderedQuantity,
      preparedQuantity,
      is_on_hold: false,
      course: i.course || 'main',
      image_url: i.image_url || prod?.image_url,
      created_at: i.created_at,
      hold_until: i.hold_until || null,
      printer_route: i.printer_route || null,
    };
  });

  return {
    id: o.id,
    table_number: o.table_number || 0,
    total_amount: o.total_amount || 0,
    created_at: o.created_at,
    kitchen_status: o.kitchen_status ?? '',
    kitchen_accepted_at: o.kitchen_accepted_at ?? null,
    kitchen_ready_at: o.kitchen_ready_at ?? null,
    void_reason: o.void_reason ?? null,
    customer_note: o.customer_note || '',
    status: o.status || 'new',
    is_rush: o.is_rush ?? false,
    merged_from_tables: o.merged_into_table ? [o.merged_into_table] : [],
    items,
  };
}

// ─── CardWithCollapse — glassmorphism card with modal on click ────────
const CardWithCollapse = memo(function CardWithCollapse({
  order, pendingItems, readyItems, allItemsReady, kitchenStatusLabel,
  isDelayed, stage, isNewlyAdded, isReadyTab,
  onAccept, onDeliver, onComplete, isAllItemsReady, formatTime, t, onSoldOut,
  lightMode, delayThreshold,
  onFireCourse, onToggleHold, onRecall, onPrintRoute,
}: {
  order: Order;
  pendingItems: OrderItem[];
  readyItems: OrderItem[];
  allItemsReady: boolean;
  kitchenStatusLabel: { text: string; color: string; badge: string; pulse: boolean };
  isDelayed: boolean;
  stage: string | null;
  isNewlyAdded: (item: OrderItem, order: Order) => boolean;
  isReadyTab: boolean;
  onAccept: () => void;
  onDeliver: () => void;
  onComplete: () => void;
  isAllItemsReady: () => boolean;
  formatTime: (c: string) => string;
  t: any;
  onSoldOut: (productId: string, productName: string) => void;
  lightMode: boolean;
  delayThreshold: number;
  onFireCourse?: (course: string) => void;
  onToggleHold?: (itemId: string, currentlyOnHold: boolean) => void;
  onRecall?: () => void;
  onPrintRoute?: (route: string) => void;
}) {
  const [showReady, setShowReady] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [soldOutConfirm, setSoldOutConfirm] = useState<{id: string; name: string} | null>(null);
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const startLongPress = (item: OrderItem) => {
    if (!item.product_id) return;
    longPressTimer.current = setTimeout(() => setSoldOutConfirm({ id: item.product_id!, name: item.product_name }), 600);
  };
  const cancelLongPress = () => { if (longPressTimer.current) clearTimeout(longPressTimer.current); };

  const allItems = [...pendingItems, ...readyItems];

  const renderItem = (item: OrderItem, idx: number, list: OrderItem[], inModal = false, forceNormal = isReadyTab) => {
    const ready       = item.preparedQuantity;
    const pending     = Math.max(0, item.orderedQuantity - item.preparedQuantity);
    const isFullyReady = pending === 0 && item.orderedQuantity > 0;
    const hasSplit    = ready > 0 && pending > 0;
    const isGlowing   = isNewlyAdded(item, order);
    const now = Date.now();
    const holdExpiry = item.hold_until ? new Date(item.hold_until).getTime() : 0;
    const isOnHold = holdExpiry > now && item.kitchen_status === 'pending';
    const holdMins = isOnHold ? Math.max(1, Math.ceil((holdExpiry - now) / 60000)) : 0;

    const onHoldClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      onToggleHold?.(item.id, isOnHold);
    };

    return (
      <div
        key={item.id}
        onMouseDown={() => startLongPress(item)}
        onMouseUp={cancelLongPress}
        onMouseLeave={cancelLongPress}
        onTouchStart={() => startLongPress(item)}
        onTouchEnd={cancelLongPress}
        className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl select-none transition-all ${
          isFullyReady && !forceNormal
            ? 'opacity-30'
            : isGlowing
              ? `bg-[${lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)'}] border ${lightMode ? 'border-gray-200' : 'border-white/10'}`
              : ''
        } ${idx !== list.length - 1 ? 'border-b border-white/[0.06]' : ''}`}
      >
        <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/8 overflow-hidden flex-shrink-0">
          {item.image_url
            ? <img src={item.image_url} alt="" className="w-full h-full object-cover" />
            : <div className="w-full h-full flex items-center justify-center text-white/20 text-[10px] font-black">{(item.product_name || '??').slice(0,2).toUpperCase()}</div>
          }
        </div>
        <div className="flex-1 min-w-0">
          {hasSplit ? (
            <div className="flex items-center gap-2">
              <div className={`w-0.5 self-stretch rounded-full flex-shrink-0 ${lightMode ? 'bg-gray-300' : 'bg-white/40'}`} />
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm leading-tight truncate text-white tracking-wide">{item.product_name}</p>
                <p className="text-xs mt-0.5">
                  <span className="text-emerald-400 font-semibold">{ready}</span>
                  <span className="text-white/25 font-normal">/{item.orderedQuantity}</span>
                  <span className="text-white/30 font-normal ml-1 text-[10px]">hazır</span>
                  <span className={`ml-1.5 font-bold text-[10px] tracking-wide ${lightMode ? 'text-gray-500' : 'text-white/50'}`}>+{pending} yeni</span>
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              {isGlowing && <div className={`w-0.5 self-stretch rounded-full flex-shrink-0 ${lightMode ? 'bg-gray-300' : 'bg-white/40'}`} />}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className={`font-bold text-sm leading-tight truncate tracking-wide ${
                    isFullyReady && !inModal && !forceNormal ? 'text-white/30' : item.is_on_hold || isOnHold ? 'text-amber-400' : 'text-white'
                  }`}>{item.product_name}</p>
                  {isOnHold && <span className={`flex-shrink-0 px-2 py-0.5 rounded-md text-[10px] font-black border tracking-wider ${lightMode ? 'bg-amber-100 border-amber-300 text-amber-700' : 'bg-amber-500/15 border-amber-500/30 text-amber-400'}`}>GÖZLƏ {holdMins}d</span>}
                </div>
                <p className="text-xs mt-0.5">
                  <span className={`font-bold text-sm ${isFullyReady ? 'text-white/20' : 'text-white/60'}`}>×{item.orderedQuantity}</span>
                  {isGlowing && <span className={`ml-1.5 font-bold text-[10px] tracking-wide ${lightMode ? 'text-gray-500' : 'text-white/50'}`}>· yeni</span>}
                </p>
              </div>
            </div>
          )}
        </div>
        {!inModal && !isReadyTab && (
          <div className="flex items-center gap-1 flex-shrink-0">
            {isOnHold ? (
              <button onClick={onHoldClick} className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center hover:bg-amber-500/25 transition-all" title="Gözləməni dayandır">
                <span className="text-xs font-black">✕</span>
              </button>
            ) : (
              <button onClick={onHoldClick} className="w-8 h-8 rounded-lg bg-white/[0.04] border border-white/[0.08] text-white/30 hover:text-amber-400 hover:border-amber-500/30 flex items-center justify-center transition-all" title="Gözlə">
                <span className="text-xs font-black">⏱</span>
              </button>
            )}
          </div>
        )}
      </div>
    );
  };

  const allDone = isAllItemsReady();

  const accentColor = allDone
    ? 'rgba(16,185,129,0.5)'
    : isDelayed
      ? 'rgba(239,68,68,0.5)'
      : lightMode ? 'rgba(0,0,0,0.5)' : 'rgba(255,255,255,0.3)';

  const cardBg = allDone
    ? lightMode ? '#f0fdf4' : '#0b120e'
    : isDelayed
      ? lightMode ? '#fef2f2' : '#120b0b'
      : lightMode ? '#f9fafb' : '#0f0f0f';

  return (
    <>
    {/* ── Sold-out confirm ── */}
    {soldOutConfirm && (
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" onClick={() => setSoldOutConfirm(null)}>
        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
        <div className="relative z-10 w-full max-w-full sm:max-w-xs rounded-2xl bg-[#151515] border border-red-500/30 shadow-2xl p-6 flex flex-col gap-4" onClick={e => e.stopPropagation()}>
          <p className="text-white font-bold text-sm text-center">«{soldOutConfirm.name}» tükəndi?</p>
          <p className="text-white/35 text-xs text-center">Müştərilərin menyusunda bu məhsul bağlanacaq</p>
          <div className="flex gap-2">
            <button onClick={() => setSoldOutConfirm(null)} className="flex-1 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/50 text-sm font-semibold hover:bg-white/[0.08] transition-all">Ləğv et</button>
            <button onClick={() => { onSoldOut(soldOutConfirm.id, soldOutConfirm.name); setSoldOutConfirm(null); }}
              className="flex-1 py-2.5 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400 text-sm font-semibold hover:bg-red-500/25 transition-all">Tükəndi</button>
          </div>
        </div>
      </div>
    )}

    {/* ── Detail Modal ── */}
    {modalOpen && (
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={() => setModalOpen(false)}>
        <div className="absolute inset-0 bg-black/80 backdrop-blur-md" />
        <div className="relative z-10 w-full sm:max-w-lg rounded-t-3xl sm:rounded-3xl overflow-hidden" style={{ background: lightMode ? '#fff' : '#111', border: `1px solid ${lightMode ? 'rgba(0,0,0,0.09)' : 'rgba(255,255,255,0.09)'}` }} onClick={e => e.stopPropagation()}>
          <div className="h-[3px]" style={{ background: `linear-gradient(90deg, transparent, ${accentColor.replace('0.5','0.9').replace('0.4','0.9').replace('0.35','0.9')}, transparent)` }} />
          <div className="px-6 pt-6 pb-4 flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-1.5">
                <h2 className="text-4xl font-black tracking-tight" style={{ color: allDone ? '#10b981' : isDelayed ? '#f87171' : (lightMode ? '#000' : '#fff') }}>
                  {t.kitchen_masa || 'MASA'} {(order.merged_from_tables||[]).length > 0 ? `${order.table_number}+${order.merged_from_tables!.join('+')}` : order.table_number}
                </h2>
                {order.is_rush && <span className="px-3 py-1 rounded-full text-xs font-black bg-orange-500/15 border border-orange-500/30 text-orange-400">{t.kitchen_rush||'TƏLƏSİR'}</span>}
              </div>
              <div className={`flex items-center gap-1.5 text-sm ${isDelayed ? 'text-red-400 font-semibold' : lightMode ? 'text-black/50' : 'text-white/35'}`}>
                {isDelayed ? <AlertTriangle size={13}/> : <Clock size={13}/>}
                <span>{formatTime(timerBase(order))} əvvəl</span>
                {isDelayed && <span className="font-black">— {t.kitchen_overdue||'GECİKMƏ!'}</span>}
                <CountdownTimer createdAt={timerBase(order)} thresholdMinutes={delayThreshold} lightMode={lightMode} />
              </div>
            </div>
            <button onClick={() => setModalOpen(false)} className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${lightMode ? 'bg-black/5 border border-black/10 text-black/40 hover:text-black' : 'bg-white/[0.06] border border-white/[0.1] text-white/50 hover:text-white'}`}>×</button>
          </div>
          <div className="h-px mx-6" style={{ background: lightMode ? 'rgba(0,0,0,0.07)' : 'rgba(255,255,255,0.07)' }} />
          <div className="px-4 py-3 space-y-0.5 max-h-[45vh] overflow-y-auto">
            {allItems.map((item, idx) => renderItem(item, idx, allItems, true))}
          </div>
           <div className="px-6 pt-3 pb-6">
             <div className="flex items-center justify-between mb-5">
               <span className={`text-sm uppercase tracking-widest font-bold ${lightMode ? 'text-black/35' : 'text-white/35'}`}>{t.kitchen_total||'CƏMİ'}</span>
               <span className={`text-3xl font-black ${lightMode ? 'text-black' : 'text-white'}`}>{order.total_amount.toFixed(2)} ₼</span>
             </div>
             {(() => {
               const routes = new Map<string, any[]>();
               order.items.forEach(it => {
                 const r = it.printer_route || 'default';
                 if (!routes.has(r)) routes.set(r, []);
                 routes.get(r)!.push(it);
               });
               if (routes.size <= 1) return null;
               return (
                 <div className="mb-4 space-y-2">
                   <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Printer Route</span>
                   {Array.from(routes.entries()).map(([route, items]) => (
                     <button key={route} onClick={(e) => { e.stopPropagation(); onPrintRoute?.(route); }}
                       className="w-full flex items-center justify-between px-3 py-2 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white/70 hover:text-white hover:bg-white/[0.08] transition-all">
                       <span className="text-xs font-bold">{route}</span>
                       <span className="text-[10px] font-black text-white/40">{items.length} item</span>
                     </button>
                   ))}
                 </div>
               );
             })()}
             {stage === 'accept' && (
              <button onClick={() => { onAccept(); setModalOpen(false); }}
                className="w-full rounded-2xl font-black flex items-center justify-center gap-3 transition-all active:scale-[0.97] hover:brightness-110"
                style={{ background: lightMode ? '#000' : '#fff', color: lightMode ? '#fff' : '#000', fontSize: 18, padding: '20px 0', letterSpacing: '0.02em', boxShadow: lightMode ? '0 4px 16px rgba(0,0,0,0.15)' : '0 4px 16px rgba(255,255,255,0.1)' }}>
                <FlameKindling size={22}/> {t.kitchen_accept||'Qəbul Et'}
              </button>
            )}
            {stage === 'deliver' && (
              <button onClick={() => { onDeliver(); setModalOpen(false); }}
                className="w-full rounded-2xl font-black flex items-center justify-center gap-3 transition-all active:scale-[0.97] hover:brightness-110"
                style={{ background: lightMode ? '#000' : '#fff', color: lightMode ? '#fff' : '#000', fontSize: 18, padding: '20px 0', boxShadow: lightMode ? '0 4px 16px rgba(0,0,0,0.15)' : '0 4px 16px rgba(255,255,255,0.1)', border: lightMode ? '1px solid rgba(255,255,255,0.15)' : '1px solid rgba(255,255,255,0.15)' }}>
                <SendHorizonal size={22}/> {t.kitchen_mark_ready||'Hazırdır — Servisə Ver'}
              </button>
            )}
          </div>
        </div>
      </div>
    )}

    {/* ── Card ── */}
    <div
      onClick={() => setModalOpen(true)}
      className="relative rounded-2xl overflow-hidden flex flex-col cursor-pointer transition-all duration-200 hover:scale-[1.015] active:scale-[0.99]"
      style={{ background: cardBg, border: `1px solid ${accentColor.replace('0.5','0.15').replace('0.4','0.12').replace('0.35','0.1')}` }}
    >
      {/* Top accent */}
      <div className="h-[2px]" style={{ background: `linear-gradient(90deg, transparent, ${accentColor}, transparent)` }} />

      {/* Void banner */}
      {order.kitchen_status === 'cancelled' && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center rounded-2xl bg-black/80 backdrop-blur-sm pointer-events-none">
          <p className="text-red-400 font-black text-base tracking-widest uppercase">Ləğv Edildi</p>
          {order.void_reason && <p className="text-white/40 text-xs mt-1 px-4 text-center">{order.void_reason}</p>}
        </div>
      )}

      {/* Header */}
      <div className="px-3 pt-3.5 pb-2.5">
        <div className="flex items-start justify-between gap-1.5">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 mb-1 flex-wrap">
              <h2 className="text-xl font-black leading-none tracking-tight" style={{ color: allDone ? '#10b981' : isDelayed ? '#f87171' : (lightMode ? '#000' : '#fff') }}>
                {t.kitchen_masa||'MASA'} {order.table_number}
              </h2>
              {(order.merged_from_tables||[]).length > 0 && (
                <div className="flex items-center gap-1">
                  <GitMerge size={10} className={lightMode ? 'text-gray-400' : 'text-white/40'} />
                  {order.merged_from_tables!.map(n => (
                    <span key={n} className={`px-1.5 py-0.5 rounded text-[10px] font-black border ${lightMode ? 'bg-gray-100 border-gray-300 text-gray-600' : 'bg-white/[0.06] border-white/[0.1] text-white/60'}`}>+{n}</span>
                  ))}
                </div>
              )}
              {order.is_rush && <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-orange-500/15 border border-orange-500/30 text-orange-400 tracking-widest">{t.kitchen_rush||'TƏLƏSİR'}</span>}
            </div>
            <div className={`flex items-center gap-1 text-[11px] ${isDelayed ? 'text-red-400/80 font-semibold' : lightMode ? 'text-black/40' : 'text-white/30'}`}>
              {isDelayed ? <AlertTriangle size={10}/> : <Clock size={10}/>}
              <span>{formatTime(timerBase(order))} əvvəl</span>
              {isDelayed && <span className="font-black">— GECİKMƏ</span>}
              <CountdownTimer createdAt={timerBase(order)} thresholdMinutes={delayThreshold} lightMode={lightMode} />
            </div>
          </div>
          <span className={`flex-shrink-0 px-2 py-1 rounded-lg text-[10px] font-black border ${kitchenStatusLabel.color} ${kitchenStatusLabel.badge} ${kitchenStatusLabel.pulse ? 'animate-pulse' : ''}`}>
            {kitchenStatusLabel.text}
          </span>
        </div>
        {order.customer_note && (
          <div className={`mt-2 px-2.5 py-1.5 rounded-lg border ${lightMode ? 'bg-gray-100 border-gray-200' : 'bg-white/[0.04] border-white/[0.08]'}`}>
            <p className={`text-[11px] leading-snug font-medium ${lightMode ? 'text-gray-700' : 'text-white/70'}`}>{order.customer_note}</p>
          </div>
        )}
      </div>

      {/* Divider */}
      <div className="mx-4 h-px bg-white/[0.05]" />

      {/* Items */}
      <div className="px-2 py-2 flex-1 space-y-0.5">
        {pendingItems.slice(0, 5).map((item, idx) => renderItem(item, idx, pendingItems))}
        {pendingItems.length > 5 && (
          <p className="text-[10px] text-white/25 px-3 py-1 font-semibold">+{pendingItems.length - 5} {t.kitchen_more||'daha'}</p>
        )}
        {readyItems.length > 0 && !isReadyTab && (
          <div onClick={e => e.stopPropagation()}>
            <button onClick={() => setShowReady(v => !v)}
              className="w-full flex items-center justify-between px-2 py-1.5 rounded-lg text-[11px] font-semibold hover:bg-white/[0.04] transition-all mt-1">
              <span className="text-emerald-400/70">{readyItems.length} hazırdır</span>
              <span className="text-white/25">{showReady ? '▴' : '▾'}</span>
            </button>
            {showReady && <div className="space-y-0.5">{readyItems.map((item, idx) => renderItem(item, idx, readyItems))}</div>}
          </div>
        )}
        {isReadyTab && readyItems.length > 0 && (
          <div className="space-y-0.5">
            {readyItems.slice(0, 4).map((item, idx) => renderItem(item, idx, readyItems))}
            {readyItems.length > 4 && <p className="text-[10px] text-emerald-400/50 px-3 py-1">+{readyItems.length - 4} daha</p>}
          </div>
        )}

         {/* Course progress */}
         {pendingItems.length > 0 && (() => {
           const courses = new Map<string, { pending: number; ready: number; total: number }>();
           order.items.forEach(it => {
             const c = it.course || 'main';
             const entry = courses.get(c) || { pending: 0, ready: 0, total: 0 };
             if (it.preparedQuantity < it.orderedQuantity) entry.pending += (it.orderedQuantity - it.preparedQuantity);
             else entry.ready += it.preparedQuantity;
             entry.total += it.orderedQuantity;
             courses.set(c, entry);
           });
           if (courses.size <= 1) return null;
           return (
             <div className="mt-3 pt-2 border-t border-white/[0.05] space-y-2">
               {Array.from(courses.entries()).map(([course, data]) => {
                 const pct = data.total > 0 ? (data.ready / data.total) * 100 : 0;
                 const allReady = data.pending === 0;
                 return (
                   <div key={course} className="space-y-1">
                     <div className="flex items-center justify-between">
                       <span className="text-[10px] font-black uppercase tracking-widest text-white/40">{course}</span>
                       <div className="flex items-center gap-2">
                         <span className="text-[10px] font-black text-white/50">{Math.round(pct)}%</span>
                         {!allReady && (
                           <button onClick={(e) => { e.stopPropagation(); onFireCourse?.(course); }}
                             className="px-2 py-0.5 rounded-md text-[9px] font-black bg-blue-500/15 border border-blue-500/30 text-blue-400 hover:bg-blue-500/25 transition-all">
                             Yandır
                           </button>
                         )}
                       </div>
                     </div>
                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                        <div className={`h-full transition-all ${lightMode ? 'bg-black' : 'bg-white'}`} style={{ width: `${pct}%` }} />
                      </div>
                   </div>
                 );
               })}
             </div>
           );
         })()}
      </div>

      {/* Footer button */}
      {(stage === 'accept' || stage === 'deliver' || stage === 'complete') && (
        <div className="px-3 pb-3 pt-1.5">
          <div className="h-px bg-white/[0.05] mb-2.5" />
           {stage === 'complete' && (
              <button onClick={(e) => { e.stopPropagation(); onRecall?.(); }}
                className="w-full rounded-xl font-black flex items-center justify-center gap-2 transition-all active:scale-[0.97] hover:brightness-110 select-none mb-2"
                style={{ background: lightMode ? '#000' : 'linear-gradient(135deg,#7c2d12,#9a3412)', color: '#fff', boxShadow: lightMode ? '0 4px 16px rgba(0,0,0,0.15)' : '0 4px 16px rgba(124,45,18,0.25)', border: lightMode ? '1px solid rgba(255,255,255,0.15)' : '1px solid rgba(255,255,255,0.08)', fontSize: 13, minHeight: 46, letterSpacing: '0.03em' }}>
                Geri çağır
              </button>
            )}
           {stage === 'accept' && (
              <button onClick={(e) => { e.stopPropagation(); onAccept(); }}
                className="w-full rounded-xl font-black flex items-center justify-center gap-2 transition-all active:scale-[0.97] hover:brightness-110 select-none"
                style={{ background: lightMode ? '#000' : '#fff', color: lightMode ? '#fff' : '#000', boxShadow: lightMode ? '0 4px 16px rgba(0,0,0,0.15)' : '0 4px 16px rgba(255,255,255,0.1)', fontSize: 13, minHeight: 46, letterSpacing: '0.03em' }}>
                <FlameKindling size={16}/> {t.kitchen_accept||'Qəbul Et'}
              </button>
            )}
           {stage === 'deliver' && (
             <button onClick={(e) => { e.stopPropagation(); onDeliver(); }}
               className="w-full rounded-xl font-black flex items-center justify-center gap-2 transition-all active:scale-[0.97] hover:brightness-110 select-none"
               style={{ background: lightMode ? '#000' : 'linear-gradient(135deg,#0f7a57,#0a5c41)', color: '#fff', boxShadow: lightMode ? '0 4px 16px rgba(0,0,0,0.15)' : '0 4px 16px rgba(16,185,129,0.18)', border: lightMode ? '1px solid rgba(255,255,255,0.15)' : '1px solid rgba(16,185,129,0.3)', fontSize: 13, minHeight: 46, letterSpacing: '0.03em' }}>
               <SendHorizonal size={16}/> {t.kitchen_mark_ready||'Hazırdır — Servisə Ver'}
             </button>
           )}
           {stage === 'complete' && (
             <button onClick={(e) => { e.stopPropagation(); onComplete(); }}
               className="w-full rounded-xl font-black flex items-center justify-center gap-2 transition-all active:scale-[0.97] hover:brightness-110 select-none"
               style={{ background: lightMode ? '#000' : 'linear-gradient(135deg,#374151,#1f2937)', color: '#fff', boxShadow: lightMode ? '0 4px 16px rgba(0,0,0,0.15)' : '0 4px 16px rgba(0,0,0,0.25)', border: lightMode ? '1px solid rgba(255,255,255,0.1)' : '1px solid rgba(255,255,255,0.08)', fontSize: 13, minHeight: 46, letterSpacing: '0.03em' }}>
               <CheckCircle2 size={16}/> {t.kitchen_complete||'Tamamla'}
             </button>
           )}
         </div>
       )}
     </div>
     </>
   );
});

let sharedCtx: AudioContext | null = null;
function playTone(freq: number, duration: number, vol = 0.4) {
  try {
    if (!sharedCtx) sharedCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = sharedCtx.createOscillator();
    const gain = sharedCtx.createGain();
    osc.connect(gain); gain.connect(sharedCtx.destination);
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(vol, sharedCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, sharedCtx.currentTime + duration);
    osc.start(); osc.stop(sharedCtx.currentTime + duration);
  } catch {}
}

function playNewOrderSound() { playTone(880, 0.15); setTimeout(() => playTone(1100, 0.2), 180); }
function playDelaySound()    { playTone(330, 0.4); setTimeout(() => playTone(280, 0.5), 450); }

// ─── Component ────────────────────────────────────────────────────────────────

export default function KitchenPage() {
  const { language, setLanguage } = useLanguage();
  const t = translations[language.toLowerCase() as keyof typeof translations] || az;

  const languages = [
    { code: 'az', label: 'AZ' },
    { code: 'en', label: 'EN' },
    { code: 'ru', label: 'RU' },
  ];

  // ── State ──────────────────────────────────────────────────────────────────
  const [showWelcome, setShowWelcome] = useState(true);
  const [orders, setOrders]           = useState<Order[]>([]);
  const [activeTab, setActiveTab]     = useState<'active' | 'ready'>('active');
  const [stationFilter, setStationFilter] = useState<string>('all');
  const [soundOn, setSoundOn]         = useState(true);
  const [langLoading, setLangLoading] = useState(false);
  const [targetLang, setTargetLang] = useState<string>('az');
  const [recentAction, setRecentAction] = useState<{
    label: string;
    prevStatus: string;
    orderId: string;
    items: { id: string; prepared_quantity: number; kitchen_status: string }[];
  } | null>(null);
  const undoTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prevLang                      = useRef(language);
  const languageRef                   = useRef(language);
  const [, forceUpdate]               = useState(0);
  const [tick, setTick]               = useState(0);
  const [delayThreshold, setDelayThreshold] = useState(15);
  const prevOrderIds                  = useRef<Set<string>>(new Set());
  const delayAlerted                  = useRef<Set<string>>(new Set());
  const delay30Alerted                = useRef<Set<string>>(new Set());
  const recentMergeRef                = useRef<{ key: string; time: number }>({ key: '', time: 0 });
  const soundOnRef                    = useRef(soundOn);
  const lastItemToastRef              = useRef<number>(0);
  const recentlyInsertedRef           = useRef<Set<string>>(new Set());
  soundOnRef.current = soundOn;

  const [viewMode, setViewMode] = useState<'cards' | 'map'>(() => {
    if (typeof window === 'undefined') return 'cards';
    try {
      const stored = window.localStorage.getItem('saito_kitchen_view_mode');
      if (stored === 'map' || stored === 'cards') return stored;
    } catch {
      // ignore
    }
    return 'cards';
  });
  const [kitchenTables, setKitchenTables] = useState<{ table_number: number }[]>([]);

  useEffect(() => {
    try {
      window.localStorage.setItem('saito_kitchen_view_mode', viewMode);
    } catch {
      // ignore
    }
  }, [viewMode]);

  // Newly added items: pending items whose created_at is newer than the order's created_at by >5 s
  // This identifies items added AFTER the original order was placed
  const isNewlyAdded = (item: OrderItem, order: Order): boolean => {
    if (order.kitchen_status === 'preparing' || order.kitchen_status === 'ready') return false;
    if (item.kitchen_status !== 'pending') return false;
    if (!item.created_at) return false;
    const itemMs  = new Date(item.created_at).getTime();
    const orderMs = new Date(order.created_at).getTime();
    return itemMs - orderMs > 5000;
  };

  // Load delay threshold from settings
  useEffect(() => {
    supabase.from('settings').select('order_delay_minutes').limit(1).then(({ data }) => {
      const val = Number(data?.[0]?.order_delay_minutes);
      if (!isNaN(val) && val >= 1) setDelayThreshold(val);
    });
  }, []);

  // Load table inventory for map view
  useEffect(() => {
    const fetchTables = async () => {
      try {
        const { data } = await supabase.from('table_floors').select('table_number').order('table_number');
        if (data) setKitchenTables(data);
      } catch {}
    };
    fetchTables();
  }, []);

  // Polling fallback (hər 15s) — realtime itirilərsə data təzə qalır
  useEffect(() => {
    const id = setInterval(() => fetchOrdersRef.current(), 15_000);
    return () => clearInterval(id);
  }, []);

  // Cleanup recently inserted order IDs after 5 seconds
  useEffect(() => {
    const id = setInterval(() => {
      recentlyInsertedRef.current.clear();
    }, 5000);
    return () => clearInterval(id);
  }, []);

  // 30-second tick — refresh relative timestamps ("əvvəl") without full refetch
  useEffect(() => {
    const id = setInterval(() => {
      forceUpdate(x => x + 1);
      setTick(t => t + 1);
    }, 30_000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => { languageRef.current = language; }, [language]);

  // ── Data mapping ───────────────────────────────────────────────────────────
  const prevItemCounts = useRef<Map<string, number>>(new Map());
  const applySeqRef = useRef(0);
  
  const applyData = useCallback((data: any[], lang: string) => {
    const mapped = data.map(o => mapRawOrder(o, lang));
    const seq = ++applySeqRef.current;

    // Sound: new order arrived OR new items added to existing order
    if (soundOnRef.current) {
      const newIds = new Set(mapped.map((o: Order) => o.id));
      let shouldPlaySound = false;
      
      mapped.forEach((o: Order) => {
        if (!prevOrderIds.current.has(o.id)) {
          shouldPlaySound = true;
        } else {
          const prevCount = prevItemCounts.current.get(o.id) || 0;
          const currentCount = o.items.reduce((sum, item) => sum + item.orderedQuantity, 0);
          if (currentCount > prevCount) {
            shouldPlaySound = true;
          }
        }
        prevItemCounts.current.set(o.id, o.items.reduce((sum, item) => sum + item.orderedQuantity, 0));
      });
      
      if (shouldPlaySound) playNewOrderSound();
      prevOrderIds.current = newIds;
    }

    setOrders(mapped);
  }, []);

  // ── Helper: Get merged table display name (e.g., "9+7" if tables are merged)
  const getMergedTableName = useCallback(async (tableNum: number | null, orderId?: string): Promise<string> => {
    if (!tableNum) return 'Naməlum masa';
    if (!orderId) return `Masa ${tableNum}`;
    
    try {
      // Find orders that were merged INTO this order
      const { data } = await supabase
        .from('orders')
        .select('table_number')
        .eq('merged_into', orderId)
        .not('table_number', 'is', null);
      
      if (data && data.length > 0) {
        const mergedNums = data.map(o => o.table_number).filter(Boolean);
        if (mergedNums.length > 0) {
          return `Masa ${tableNum}+${mergedNums.join('+')}`;
        }
      }
      return `Masa ${tableNum}`;
    } catch {
      return `Masa ${tableNum}`;
    }
  }, []);

  // ── Fetch (fallback) ───────────────────────────────────────────────────────
  const fetchOrdersRef = useRef<() => Promise<void>>(async () => {});

  const fetchOrders = useCallback(async () => {
    try {
      const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
      const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
      
      if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
        console.error('[Kitchen] Missing Supabase credentials');
        return;
      }

      const queryParams = new URLSearchParams({
        select: '*,order_items(*,products(image_url,translations)),merged_into_table:orders!merged_into(table_number)',
        'table_number': 'gt.0',
        'status': 'not.in.(paid,cancelled,closed,completed)',
        'kitchen_status': 'neq.completed',
        order: 'created_at.desc'
      });

      const response = await fetch(`${SUPABASE_URL}/rest/v1/orders?${queryParams.toString()}`, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      if (data) {
        applyData(data, languageRef.current);
        localStorage.setItem('saito_kitchen_data', JSON.stringify(data));
      } else {
      }
    } catch (err) {
      const cached = localStorage.getItem('saito_kitchen_data');
      if (cached) {
        try {
          applyData(JSON.parse(cached), languageRef.current);
        } catch (e) {
          console.error('[Kitchen] Cache parse error:', e);
        }
      } else {
      }
    }
  }, [applyData]);

  const manualRefresh = useCallback(async () => {
    await fetchOrdersRef.current();
  }, []);

  // keep ref in sync — also assign immediately after creation
  fetchOrdersRef.current = fetchOrders;
  useEffect(() => { fetchOrdersRef.current = fetchOrders; }, [fetchOrders]);

  // ── Initial fetch — guaranteed with latest reference
  useEffect(() => { 
    fetchOrders(); 
    
    // Check for offline queued orders on mount
    (async () => {
      try {
        const queued = await localStore.getOutbox();
        if (queued.length > 0 && navigator.onLine) {
          // Try to sync pending actions
          const { syncNow } = await import('@/lib/sync/SyncService');
          await syncNow();
        }
      } catch {}
    })();
  }, [fetchOrders]);

  // ── Supabase Realtime subscription — with debounce for CPU relief
  useEffect(() => {
    let debounceTimer: ReturnType<typeof setTimeout> | null = null;
    const debouncedFetch = () => {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => fetchOrdersRef.current(), 400);
    };
    
    const channel = createRealtimeChannel('kitchen_realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, async (payload: any) => {
        debouncedFetch();
        
        // Detect table merge: when an order gets merged_into set
        const isMerge = payload.new?.merged_into && !payload.old?.merged_into;
        if (isMerge) {
          const targetTableNum = payload.new?.table_number;
          const targetOrderId = payload.new?.merged_into;
          const mergeKey = `${targetOrderId}-${targetTableNum}`;
          const now = Date.now();
          if (recentMergeRef.current.key === mergeKey && (now - recentMergeRef.current.time) < 2000) return;
          recentMergeRef.current = { key: mergeKey, time: now };
          const { data: targetOrder } = await supabase.from('orders').select('table_number').eq('id', targetOrderId).single();
          const targetTable = targetOrder?.table_number;
          toast.custom((_t) => (
            <motion.div
              initial={{ opacity: 0, y: -16, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 100 }}
              style={{ background: lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.03)', border: `1px solid ${lightMode ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.1)'}`, borderRadius: 18, padding: '14px 18px', boxShadow: lightMode ? '0 4px 16px rgba(0,0,0,0.1)' : '0 8px 32px rgba(0,0,0,0.3)', minWidth: 260, pointerEvents: 'auto' }}
              className="flex items-center gap-4"
            >
              <div style={{ width: 44, height: 44, borderRadius: 14, background: lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.08)', border: `1px solid ${lightMode ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.15)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <GitMerge size={20} color={lightMode ? '#000' : '#fff'} />
              </div>
              <div>
                <p style={{ fontSize: 15, fontWeight: 800, color: lightMode ? '#000' : '#fff', lineHeight: 1.2 }}>
                  {targetTable ? `Masa ${targetTable}` : ''}{targetTable && targetTableNum ? <span style={{ color: lightMode ? 'rgba(0,0,0,0.4)' : 'rgba(255,255,255,0.4)' }}> + </span> : ''}{targetTableNum}
                </p>
                <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)', marginTop: 2, fontWeight: 600 }}>Masalar birləşdirildi</p>
              </div>
            </motion.div>
          ), { duration: 2500, position: 'top-right' });
          if (soundOnRef.current) playNewOrderSound();
          return;
        }

        // New order inserted
        const isNewOrder = payload.eventType === 'INSERT' && !payload.old;
        if (isNewOrder && payload.new?.id) {
          recentlyInsertedRef.current.add(payload.new.id);
          const tableNum = payload.new?.table_number;
          const tableName = await getMergedTableName(tableNum, payload.new?.id);
          toast.custom((_t) => (
            <motion.div
              initial={{ opacity: 0, y: -16, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 100 }}
              style={{ background: lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.03)', border: `1px solid ${lightMode ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.1)'}`, borderRadius: 18, padding: '14px 18px', boxShadow: lightMode ? '0 4px 16px rgba(0,0,0,0.1)' : '0 8px 32px rgba(0,0,0,0.3)', minWidth: 260, pointerEvents: 'auto' }}
              className="flex items-center gap-4"
            >
              <div style={{ width: 44, height: 44, borderRadius: 14, background: lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.08)', border: `1px solid ${lightMode ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.15)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 22 }}>+</div>
              <div>
                <p style={{ fontSize: 15, fontWeight: 800, color: lightMode ? '#000' : '#fff', lineHeight: 1.2 }}>{tableName}</p>
                <p style={{ fontSize: 11, color: lightMode ? 'rgba(0,0,0,0.4)' : 'rgba(255,255,255,0.4)', marginTop: 2, fontWeight: 600 }}>Yeni sifariş</p>
              </div>
            </motion.div>
          ), { duration: 2500, position: 'top-right' });
          if (soundOnRef.current) playNewOrderSound();
          return;
        }
        
        // Admin sifarişi dəyişdirdisə — yenilənmə bildirişi
        const isReset =
          payload.eventType === 'UPDATE' &&
          !payload.new?.merged_into &&
          payload.new?.kitchen_status === 'pending' &&
          (payload.old?.kitchen_status !== 'pending' || payload.new?.total_amount !== payload.old?.total_amount);
        
        // Skip reset toast for recently inserted orders to avoid duplicate notifications
        if (isReset && payload.new?.id && recentlyInsertedRef.current.has(payload.new.id)) {
          return;
        }
        
        if (isReset) {
          const tableNum = payload.new?.table_number;
          const tableName = await getMergedTableName(tableNum, payload.new?.id);
          toast.custom((_t) => (
            <motion.div
              initial={{ opacity: 0, y: -16, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 100 }}
              style={{ background: 'linear-gradient(135deg,#101a10,#080e08)', border: '1px solid rgba(52,211,153,0.3)', borderRadius: 18, padding: '14px 18px', boxShadow: '0 8px 32px rgba(0,0,0,0.6)', minWidth: 260, pointerEvents: 'auto' }}
              className="flex items-center gap-4"
            >
              <div style={{ width: 44, height: 44, borderRadius: 14, background: 'rgba(52,211,153,0.1)', border: '1px solid rgba(52,211,153,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 22 }}>⟳</div>
              <div>
                <p style={{ fontSize: 15, fontWeight: 800, color: '#6ee7b7', lineHeight: 1.2 }}>{tableName}</p>
                <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 2, fontWeight: 600 }}>Sifariş yeniləndi</p>
              </div>
            </motion.div>
          ), { duration: 2500, position: 'top-right' });
          if (soundOnRef.current) playNewOrderSound();
        }

        // Unmerge: merged_into was set, now cleared
        const isUnmerge = !payload.new?.merged_into && payload.old?.merged_into;
        if (isUnmerge) {
          const tableNum = payload.new?.table_number;
          toast.custom((_t) => (
            <motion.div
              initial={{ opacity: 0, y: -16, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 100 }}
              style={{ background: 'linear-gradient(135deg,#0d1218,#080e14)', border: '1px solid rgba(99,179,237,0.35)', borderRadius: 18, padding: '14px 18px', boxShadow: '0 8px 32px rgba(0,0,0,0.6)', minWidth: 260, pointerEvents: 'auto' }}
              className="flex items-center gap-4"
            >
              <div style={{ width: 44, height: 44, borderRadius: 14, background: 'rgba(99,179,237,0.1)', border: '1px solid rgba(99,179,237,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Scissors size={20} color="#90cdf4" />
              </div>
              <div>
                <p style={{ fontSize: 15, fontWeight: 800, color: '#90cdf4', lineHeight: 1.2 }}>Masa {tableNum}</p>
                <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 2, fontWeight: 600 }}>Ayrıldı — öz sifarişi var</p>
              </div>
            </motion.div>
          ), { duration: 2500, position: 'top-right' });
          return;
        }

      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'order_items' }, async (payload: any) => {
        fetchOrdersRef.current();
        if (payload.eventType === 'INSERT' && soundOnRef.current) {
          const now = Date.now();
          if (now - lastItemToastRef.current < 2000) return;
          lastItemToastRef.current = now;
          setTimeout(() => playNewOrderSound(), 100);
        }
      })
      .subscribe();

    return () => { 
      if (debounceTimer) clearTimeout(debounceTimer);
      removeRealtimeChannel(channel); 
    };
  }, [getMergedTableName]);

  useEffect(() => {
    if (prevLang.current === language) return;
    prevLang.current = language;
    setLangLoading(true);
    fetchOrdersRef.current();
    const timer = setTimeout(() => setLangLoading(false), 900);
    return () => clearTimeout(timer);
  }, [language]);

  // ── Delay warning sound (15 min + 30 min toast) ───────────────────────────
  useEffect(() => {
    if (!soundOn) return;
    orders.forEach(order => {
      const isPreparing = order.kitchen_status === 'preparing' || order.status === 'preparing';
      if (!isPreparing || !order.kitchen_accepted_at) return;
      if (!delayAlerted.current.has(order.id) && elapsedMinutes(timerBase(order)) >= 15) {
        delayAlerted.current.add(order.id);
        playDelaySound();
      }
      if (!delay30Alerted.current.has(order.id) && elapsedMinutes(timerBase(order)) >= 30) {
        delay30Alerted.current.add(order.id);
        toast.custom((_t) => (
          <motion.div initial={{ opacity: 0, y: -16, scale: 0.94 }} animate={{ opacity: 1, y: 0, scale: 1, rotate: [0, -1, 1, 0] }} transition={{ repeat: Infinity, repeatDelay: 0.8, duration: 0.3 }} exit={{ opacity: 0, x: 100 }} style={{ background: 'linear-gradient(135deg,#2a0a0a,#180808)', border: '1px solid rgba(239,68,68,0.45)', borderRadius: 18, padding: '14px 18px', boxShadow: '0 8px 32px rgba(0,0,0,0.6)', minWidth: 260, pointerEvents: 'auto' }} className="flex items-center gap-4">
            <div style={{ width: 44, height: 44, borderRadius: 14, background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.35)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><AlertTriangle size={22} color="#f87171" /></div>
            <div><p style={{ fontSize: 15, fontWeight: 800, color: '#fca5a5', lineHeight: 1.2 }}>Masa {order.table_number}</p><p style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)', marginTop: 2, fontWeight: 600 }}>30 dəqiqədən artıq gecikdi!</p></div>
          </motion.div>
        ), { duration: 2500, position: 'top-right' });
        playDelaySound();
      }
    });
  }, [orders, soundOn, tick]);

  // Clear stale delay-alert dedupe refs for orders no longer present
  useEffect(() => {
    const currentIds = new Set(orders.map(o => o.id));
    delayAlerted.current = new Set([...delayAlerted.current].filter(id => currentIds.has(id)));
    delay30Alerted.current = new Set([...delay30Alerted.current].filter(id => currentIds.has(id)));
  }, [orders]);

  // ── Undo helper ────────────────────────────────────────────────────────────
  const pushUndo = (label: string, order: Order) => {
    if (undoTimer.current) clearTimeout(undoTimer.current);
    setRecentAction({
      label,
      orderId: order.id,
      prevStatus: order.kitchen_status,
      items: order.items.map(it => ({
        id: it.id,
        prepared_quantity: it.preparedQuantity,
        kitchen_status: it.kitchen_status || 'pending',
      })),
    });
    undoTimer.current = setTimeout(() => setRecentAction(null), 8000);
  };

  const handleUndo = async () => {
    if (!recentAction) return;
    setRecentAction(null);
    if (undoTimer.current) clearTimeout(undoTimer.current);
    for (const it of recentAction.items) {
      await supabase.rpc('update_order_item_status', {
        p_order_item_id: it.id,
        p_status: it.kitchen_status,
        p_prepared_quantity: it.prepared_quantity,
      });
    }
    fetchOrdersRef.current();
  };

  // ── DB actions (all through RPCs — SSOT) ───────────────────────────────────
  const updateOrderStatus = async (id: string, newStatus: 'preparing' | 'ready' | 'completed') => {
    if (newStatus === 'completed') {
      const order = orders.find(o => o.id === id);
      if (order) pushUndo(`MASA ${order.table_number} — tamamlandı`, order);
      const startTime = Date.now();
      const { error: rpcError } = await supabase.rpc('mark_order_ready', { p_order_id: id });
      if (rpcError) {
        console.error('[updateOrderStatus] mark_order_ready failed:', rpcError);
        toast.error('Status yenilənərkən xəta baş verdi', { duration: 2500 });
        return;
      }
      const prepTime = Math.round((Date.now() - startTime) / 1000);
      const station = order?.items?.[0]?.station || 'all';
      recordAnalytics(id, order?.items?.[0]?.id || '', station, 'complete', prepTime, order?.kitchen_status === 'preparing');
      const { error: updateError } = await supabase.from('orders').update({ status: 'completed', kitchen_status: 'completed', completed_at: new Date().toISOString() }).eq('id', id);
      if (updateError) {
        console.error('[updateOrderStatus] order update failed:', updateError);
        toast.error('Status yenilənərkən xəta baş verdi', { duration: 2500 });
        return;
      }
    } else if (newStatus === 'preparing') {
      const { error } = await supabase.rpc('prepare_order_items', { p_order_id: id });
      if (error) {
        console.error('[updateOrderStatus] prepare_order_items failed:', error);
        toast.error('Status yenilənərkən xəta baş verdi', { duration: 2500 });
        return;
      }
    } else if (newStatus === 'ready') {
      const { error } = await supabase.rpc('mark_order_ready', { p_order_id: id });
      if (error) {
        console.error('[updateOrderStatus] mark_order_ready failed:', error);
        toast.error('Status yenilənərkən xəta baş verdi', { duration: 2500 });
        return;
      }
    }
    fetchOrdersRef.current();
  };

  // Addım 2: Təhvil Ver — itemləri ready edir + stock deduction (atomik RPC)
  // mark_order_ready handles: FOR UPDATE, item status, order status, stock deduction, audit
  const markAllReadyAndNotify = async (order: Order) => {
    pushUndo(`MASA ${order.table_number} — servise verildi`, order);
    const startTime = Date.now();
    const { error } = await supabase.rpc('mark_order_ready', { p_order_id: order.id });
    if (error) {
      console.error('[kitchen] mark_order_ready failed:', error);
      toast.error('Status yenilənərkən xəta baş verdi', { duration: 2500 });
      return;
    }
    const prepTime = Math.round((Date.now() - startTime) / 1000);
    const station = order.items[0]?.station || 'all';
    recordAnalytics(order.id, order.items[0]?.id || '', station, 'deliver', prepTime, false);
    fetchOrdersRef.current();
    if (activeTab !== 'ready') setActiveTab('ready');
  };

  // ── Derived state ──────────────────────────────────────────────────────────
  const { activeOrders, readyOrders } = useMemo(() => {
    const filtered = stationFilter === 'all' ? orders : orders.filter(o => o.items.some(it => it.station === stationFilter));
    const active = filtered
      .filter(o => o.items.length > 0 && o.items.some(it => it.preparedQuantity < it.orderedQuantity))
      .sort((a, b) => priorityWeight(a) - priorityWeight(b) || new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    const ready = filtered.filter(o =>
      o.items.length > 0 &&
      o.items.every(it => it.preparedQuantity >= it.orderedQuantity)
    );
    return { activeOrders: active, readyOrders: ready };
  }, [orders, stationFilter]);

  const display = activeTab === 'active' ? activeOrders : readyOrders;

  // ── Smart Queue: group items by product across all active orders ───────────
  const groupedQueue = useMemo(() => {
    const map = new Map<string, { product_name: string; image_url?: string; totalPending: number; tables: number[] }>();
    activeOrders.forEach(order => {
      order.items.forEach(item => {
        const pending = Math.max(0, item.orderedQuantity - item.preparedQuantity);
        if (pending === 0) return;
        const key = item.product_id || item.product_name;
        const existing = map.get(key);
        if (existing) {
          existing.totalPending += pending;
          if (!existing.tables.includes(order.table_number)) existing.tables.push(order.table_number);
        } else {
          map.set(key, { product_name: item.product_name, image_url: item.image_url, totalPending: pending, tables: [order.table_number] });
        }
      });
    });
    return Array.from(map.values()).sort((a, b) => b.totalPending - a.totalPending);
  }, [activeOrders]);

  // ── Sifarişi qəbul et — atomik RPC (FOR UPDATE + status transition)
  const acceptOrder = async (order: Order) => {
    try {
      const session = localStorage.getItem('saito_staff_session');
      const staffId = session ? JSON.parse(session).id : null;
      await supabase.from('orders').update({ assigned_to: staffId }).eq('id', order.id);
    } catch {}
    const startTime = Date.now();
    const { error } = await supabase.rpc('prepare_order_items', { p_order_id: order.id });
    if (error) {
      console.error('[acceptOrder] error:', error);
      toast.error('Sifariş qəbul edilərkən xəta baş verdi', { duration: 2500 });
      return;
    }
    const prepTime = Math.round((Date.now() - startTime) / 1000);
    const station = order.items[0]?.station || 'all';
    recordAnalytics(order.id, order.items[0]?.id || '', station, 'accept', prepTime, false);
    fetchOrdersRef.current();
  };

  // ── Smart Button məntiqini hesabla ────────────────────────────────────────
  // Mərhələ 1: kitchen_status = null | 'pending' | 'cooking' → "Sifarişi Qəbul Et"
  // Mərhələ 2: kitchen_status = 'preparing'                  → "Təhvil Ver"
  // Mərhələ 3: kitchen_status = 'ready'                       → Hazır tabı
  const getSmartButtonStage = (order: Order): 'accept' | 'deliver' | 'complete' | null => {
    const allReady = isAllItemsReady(order);
    if (allReady) return 'complete';
    if (order.kitchen_status === 'preparing') return 'deliver';
    if (['pending', 'cooking'].includes(order.kitchen_status)) return 'accept';
    return null;
  };

  // ── Sold Out handler ───────────────────────────────────────────────────────
  // Real stock-dan asılı olsun: həmin məhsulun reseptindəki ingredient-lərin
  // stokunu 0 waste entry ilə inventory_logs-a yaz → trigger avtomatik
  // products.is_available = false edəcək
  const handleSoldOut = async (productId: string, productName: string) => {
    try {
      const res = await fetch('/api/kitchen/sold-out', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ product_id: productId, product_name: productName }),
      });
      if (res.ok) {
        toast.success(`${productName} bağlandı`, { duration: 2500, style: { background: '#1a0a0a', color: '#f87171', border: '1px solid rgba(239,68,68,0.4)', fontWeight: 'bold' } });
      } else {
        const err = await res.json();
        toast.error(err.error || 'Xəta', { duration: 2500 });
      }
    } catch {
      toast.error('Xəta', { duration: 2500 });
    }
  };

  // ── Analytics recorder ──────────────────────────────────────────────────────
  const recordAnalytics = async (orderId: string, orderItemId: string, station: string, action: 'accept' | 'deliver' | 'complete', prepTimeSeconds?: number, rush: boolean = false) => {
    try {
      const session = localStorage.getItem('saito_staff_session');
      const staffId = session ? JSON.parse(session).id : null;
      await fetch('/api/kitchen/analytics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          order_id: orderId,
          order_item_id: orderItemId,
          station,
          action,
          prep_time_seconds: prepTimeSeconds,
          rush,
        }),
      });
    } catch {}
  };

  // ── Fire Course handler ──────────────────────────────────────────────────────
  const fireCourse = async (order: Order, course: string) => {
    try {
      const { error } = await supabase.rpc('fire_course_atomic', {
        p_order_id: order.id,
        p_course: course,
      });
      if (error) {
        toast.error('Kurs yandırılarkən xəta baş verdi', { duration: 2500 });
        return;
      }
      toast.success(`"${course}" kursu yandırıldı`, { duration: 2500 });
      fetchOrdersRef.current();
    } catch {
      toast.error('Xəta', { duration: 2500 });
    }
  };

  // ── Hold/Release Hold handler ───────────────────────────────────────────────
  const toggleHold = async (itemId: string, currentlyOnHold: boolean) => {
    try {
      if (currentlyOnHold) {
        const { error } = await supabase.rpc('release_item_hold', { p_order_item_id: itemId });
        if (error) throw error;
        toast.success('Gözləmə dayandırıldı', { duration: 2500 });
      } else {
        const { error } = await supabase.rpc('set_item_hold', { p_order_item_id: itemId, p_hold_minutes: 20 });
        if (error) throw error;
        toast.success('20 dəqiqəyə götürüldü', { duration: 2500 });
      }
      fetchOrdersRef.current();
    } catch {
      toast.error('Xəta', { duration: 2500 });
    }
  };

  // ── Recall handler ──────────────────────────────────────────────────────────
  const recallOrder = async (order: Order) => {
    try {
      const { error } = await supabase.rpc('recall_order_items', { p_order_id: order.id });
      if (error) {
        toast.error('Sifariş geri çağırıla bilmədi', { duration: 2500 });
        return;
      }
      toast.success('Sifariş geri çağırıldı', { duration: 2500 });
      fetchOrdersRef.current();
    } catch {
      toast.error('Xəta', { duration: 2500 });
    }
  };

  // ── Print route handler ─────────────────────────────────────────────────────
  const printRoute = async (orderId: string, route: string) => {
    try {
      const { data, error } = await supabase.rpc('route_kitchen_order', { p_order_id: orderId });
      if (error || !data?.success) {
        toast.error('Route məlumatı alına bilmədi', { duration: 2500 });
        return;
      }
      const routeItems = data.routes?.[route] || [];
      const text = routeItems.map((it: any) => `×${it.quantity} ${it.product_name}`).join('\n');
      if (navigator.clipboard && text) {
        await navigator.clipboard.writeText(`Masa ${orderId} — ${route}:\n${text}`);
        toast.success(`${route} kopyalandı`, { duration: 2500 });
      }
    } catch {
      toast.error('Xəta', { duration: 2500 });
    }
  };

  // ── Render helpers ─────────────────────────────────────────────────────────
  const renderOrderCard = (order: Order) => {
    const allItemsReady = order.items.length > 0 && order.items.every(it => it.preparedQuantity >= it.orderedQuantity);
    const kitchenStatusLabel = (() => {
      if (order.is_draft || order.kitchen_status === 'reserved') {
        return { text: 'RESERV', color: lightMode ? 'text-gray-500' : 'text-indigo-300', badge: lightMode ? 'bg-gray-100 border-gray-300' : 'bg-indigo-500/20 border-indigo-400/30', pulse: true };
      }
      if (allItemsReady)                         return { text: 'Hazırdır',   color: 'text-emerald-300', badge: 'bg-emerald-500/15 border-emerald-400/30', pulse: false };
      if (order.kitchen_status === 'preparing')  return { text: 'Hazırlanır', color: 'text-blue-300',    badge: 'bg-blue-500/15 border-blue-400/30',       pulse: false };
      return { text: 'YENİ', color: lightMode ? 'text-gray-500' : 'text-white/60', badge: lightMode ? 'bg-gray-100 border-gray-300' : 'bg-white/[0.08] border-white/[0.12]', pulse: true };
    })();

    const mins = elapsedMinutes(timerBase(order));
    const isDelayed = !!order.kitchen_accepted_at && mins >= delayThreshold && !allItemsReady;
    const stage = getSmartButtonStage(order);

    // Sort: newly-added pending first, then other pending, then ready
    const sortedItems = [...order.items].sort((a, b) => {
      const aNew = isNewlyAdded(a, order) ? 0 : a.kitchen_status === 'pending' ? 1 : 2;
      const bNew = isNewlyAdded(b, order) ? 0 : b.kitchen_status === 'pending' ? 1 : 2;
      if (aNew !== bNew) return aNew - bNew;
      return new Date(a.created_at || 0).getTime() - new Date(b.created_at || 0).getTime();
    });

    const pendingItems = sortedItems.filter(it => it.preparedQuantity < it.orderedQuantity);
    const readyItems   = sortedItems.filter(it => it.preparedQuantity >= it.orderedQuantity && it.orderedQuantity > 0);

    return (
      <CardWithCollapse
        key={order.id}
        order={order}
        pendingItems={pendingItems}
        readyItems={readyItems}
        allItemsReady={allItemsReady}
        kitchenStatusLabel={kitchenStatusLabel}
        isDelayed={isDelayed}
        stage={stage}
        isNewlyAdded={isNewlyAdded}
        isReadyTab={activeTab === 'ready'}
        onAccept={() => acceptOrder(order)}
        onDeliver={() => markAllReadyAndNotify(order)}
        onComplete={() => updateOrderStatus(order.id, 'completed')}
        isAllItemsReady={() => isAllItemsReady(order)}
        formatTime={(c: string) => formatTime(c, t)}
        t={t}
        onSoldOut={handleSoldOut}
        lightMode={lightMode}
        delayThreshold={delayThreshold}
        onFireCourse={(course) => fireCourse(order, course)}
        onToggleHold={(itemId, currentlyOnHold) => toggleHold(itemId, currentlyOnHold)}
        onRecall={() => recallOrder(order)}
        onPrintRoute={(route) => printRoute(order.id, route)}
      />
    );
  };

   // ── Main render ────────────────────────────────────────────────────────────
   const { lightMode, setLightMode } = useTheme();
  return (
    <div className={`min-h-screen p-4 sm:p-6 lg:p-8 ${lightMode ? 'bg-white text-black' : 'bg-[#0a0a0a] text-white'}`}>
      {showWelcome && (
        <WelcomeScreen role="kitchen" onDismiss={() => setShowWelcome(false)} />
      )}

      <AnimatePresence>
        {langLoading && (() => {
          const LANG_TEXT: Record<string, string> = { az: 'DİL DƏYİŞDİRİLİR', en: 'SWITCHING LANGUAGE', ru: 'СМЕНА ЯЗЫКА' };
          const waveChars = (LANG_TEXT[targetLang] || LANG_TEXT.az).split('');
          return (
            <motion.div
              key="lang-overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="fixed inset-0 z-[200] pointer-events-none"
              style={{ background: 'rgba(4,4,4,0.8)', backdropFilter: 'blur(6px)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}
            >
              {/* Radial glow */}
              <div style={{ position: 'absolute', width: 220, height: 220, borderRadius: '50%', background: 'radial-gradient(circle, rgba(212,175,55,0.08) 0%, transparent 70%)', filter: 'blur(18px)' }} />

              {/* Globe + rings */}
              <div style={{ position: 'relative', width: 100, height: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}>
                <div style={{ position: 'absolute', inset: -4, borderRadius: '50%', border: '1px solid rgba(212,175,55,0.12)', borderTopColor: 'rgba(212,175,55,0.85)', borderBottomColor: 'rgba(212,175,55,0.08)', animation: 'orbitCW 2.2s linear infinite', transform: 'scaleY(0.35)', boxShadow: '0 0 8px rgba(212,175,55,0.2)' }} />
                <div style={{ position: 'absolute', inset: 4, borderRadius: '50%', border: '1px solid rgba(212,175,55,0.08)', borderLeftColor: 'rgba(212,175,55,0.75)', borderRightColor: 'rgba(212,175,55,0.06)', animation: 'orbitCCW 1.6s linear infinite', transform: 'rotate(60deg) scaleY(0.4)', boxShadow: '0 0 6px rgba(212,175,55,0.15)' }} />
                <div style={{ position: 'absolute', inset: 14, borderRadius: '50%', border: '1px solid rgba(212,175,55,0.06)', borderTopColor: 'rgba(212,175,55,0.5)', animation: 'orbitCW 1s linear infinite', transform: 'rotate(-30deg) scaleY(0.3)' }} />
                <motion.svg width="48" height="48" viewBox="0 0 24 24" fill="none" strokeLinecap="round" strokeLinejoin="round"
                  animate={{ rotateY: [0, 360] }} transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
                  style={{ filter: 'drop-shadow(0 0 6px rgba(212,175,55,0.5))' }}
                >
                  <circle cx="12" cy="12" r="10" stroke="rgba(212,175,55,0.5)" strokeWidth="1"/>
                  <path d="M2 12h20" stroke="rgba(212,175,55,0.35)" strokeWidth="0.8"/>
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" stroke="rgba(212,175,55,0.7)" strokeWidth="1"/>
                  <path d="M2 7h20M2 17h20" stroke="rgba(212,175,55,0.2)" strokeWidth="0.6"/>
                </motion.svg>
                <motion.div
                  animate={{ opacity: [0.4, 1, 0.4], scale: [0.8, 1.2, 0.8] }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                  style={{ position: 'absolute', width: 6, height: 6, borderRadius: '50%', background: 'rgba(212,175,55,0.9)', boxShadow: '0 0 12px 4px rgba(212,175,55,0.5)' }}
                />
              </div>

              {/* Wave text */}
              <div style={{ display: 'flex', gap: 3 }}>
                {waveChars.map((ch, i) => (
                  <motion.span key={i}
                    animate={{ opacity: [0.15, 1, 0.15] }}
                    transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut', delay: i * 0.07 }}
                     style={{ fontSize: ch === ' ' ? 8 : 13, fontWeight: 800, letterSpacing: '0.05em', color: lightMode ? '#000' : '#fff', width: ch === ' ' ? 6 : 'auto', display: 'inline-block' }}
                  >{ch === ' ' ? '\u00A0' : ch}</motion.span>
                ))}
              </div>
            </motion.div>
          );
        })()}
      </AnimatePresence>

      {/* ── Header ── */}
      <header className="flex flex-wrap items-start justify-between gap-4 mb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-white/[0.06] border border-white/[0.08] flex items-center justify-center flex-shrink-0">
            <ChefHat size={22} className={lightMode ? 'text-black' : 'text-white'} />
          </div>
          <div>
            <h1 suppressHydrationWarning className="text-xl font-black text-white/90 leading-none tracking-wide">{t.kitchen_panel || 'Mətbəx'}</h1>
            <p suppressHydrationWarning className="text-sm text-white/30 mt-1">{activeOrders.length} aktiv · {readyOrders.length} hazır</p>
          </div>
          {/* Chef Dashboard Stats */}
          <div className="hidden lg:flex items-center gap-3 ml-4">
            <div className="px-3 py-1.5 rounded-xl bg-white/[0.04] border border-white/[0.06] text-center">
              <p className="text-[10px] font-black text-white/40 uppercase tracking-wider">Aktiv</p>
              <p className="text-sm font-black text-white">{activeOrders.length}</p>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-white/[0.04] border border-white/[0.06] text-center">
              <p className="text-[10px] font-black text-white/40 uppercase tracking-wider">Hazır</p>
              <p className="text-sm font-black text-emerald-400">{readyOrders.length}</p>
            </div>
          </div>
          {/* AI Scheduler */}
          <div className="hidden md:block">
            <KitchenAIScheduler lightMode={lightMode} />
          </div>
        </div>

         <div className="flex items-center gap-2.5">
           {/* View mode */}
           <div className="flex bg-white/[0.04] border border-white/[0.07] rounded-xl p-1">
             <button onClick={() => setViewMode('cards')} className={`px-3 py-1.5 rounded-lg text-[10px] font-black transition-all flex items-center gap-1 ${viewMode === 'cards' ? (lightMode ? 'bg-black text-white' : 'bg-white/10 text-white') : (lightMode ? 'text-black/50 hover:text-black' : 'text-white/40 hover:text-white/70')}`}><LayoutGrid size={12}/>Kart</button>
             <button onClick={() => setViewMode('map')} className={`px-3 py-1.5 rounded-lg text-[10px] font-black transition-all flex items-center gap-1 ${viewMode === 'map' ? (lightMode ? 'bg-black text-white' : 'bg-white/10 text-white') : (lightMode ? 'text-black/50 hover:text-black' : 'text-white/40 hover:text-white/70')}`}><MapIcon size={12}/>Xəritə</button>
           </div>

           {/* Manual refresh */}
           <button onClick={manualRefresh}
             className="px-3 py-1.5 rounded-lg text-[10px] font-black bg-white/[0.06] border border-white/[0.1] text-white/60 hover:text-white hover:bg-white/[0.1] transition-all">
             Yenilə
           </button>

          {/* Theme toggle */}
          <button onClick={() => { try { setLightMode(!lightMode); } catch {} }} className={`w-11 h-11 rounded-xl border flex items-center justify-center transition-all ${lightMode ? 'bg-black text-white border-black' : 'bg-white/[0.03] border-white/[0.08] text-white/30 hover:text-white/70'}`}>
            {lightMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>

           {/* Language switcher */}
           <div className={`flex items-center rounded-lg p-0.5 ${lightMode ? 'bg-black/5 border border-black/10' : 'bg-white/[0.04] border border-white/[0.07]'}`}>
             {languages.map(lang => (
               <button key={lang.code}
                 onClick={() => { setTargetLang(lang.code); setLanguage(lang.code as any); }}
                 className={`px-2.5 py-1 text-[10px] font-black rounded-md transition-all ${language === lang.code ? (lightMode ? 'bg-black text-white' : 'bg-white text-black') : (lightMode ? 'text-black/50 hover:text-black' : 'text-white/40 hover:text-white/70')}`}
               >{lang.label}</button>
             ))}
           </div>

          {/* Sound toggle */}
          <button onClick={() => setSoundOn(v => !v)}
            className={`w-11 h-11 rounded-xl border flex items-center justify-center transition-all ${soundOn ? (lightMode ? 'bg-black text-white border-black' : 'bg-white text-black border-white') : (lightMode ? 'bg-black/5 text-black/40 border-black/10' : 'bg-white/[0.03] border-white/[0.08] text-white/30')}`}>
            {soundOn ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>

          {/* Logout */}
          <button onClick={async () => { await supabase.auth.signOut(); window.location.href = '/'; }}
            className={`w-11 h-11 rounded-xl border flex items-center justify-center transition-all ${lightMode ? 'bg-black/5 border-black/10 text-black/40 hover:text-red-500 hover:bg-red-50' : 'bg-white/[0.03] border-white/[0.08] text-white/30 hover:text-red-400 hover:bg-red-500/8 hover:border-red-500/20'}`}>
            <LogOut size={18} />
          </button>

          {/* Tabs */}
           <div className={`flex rounded-2xl p-1 ${lightMode ? 'bg-black/5 border border-black/10' : 'bg-white/[0.04] border border-white/[0.07]'}`}>
             <button onClick={() => setActiveTab('active')}
               className={`px-5 py-2.5 rounded-xl text-sm font-black transition-all ${activeTab === 'active' ? (lightMode ? 'bg-black text-white' : 'bg-white/[0.1] text-white') : (lightMode ? 'text-black/50 hover:text-black' : 'text-white/35 hover:text-white/60')}`}>
               {t.kitchen_active||'Aktiv'}
               {activeOrders.length > 0 && <span className={`ml-2 px-2 py-0.5 rounded-full text-xs font-black ${activeTab === 'active' ? (lightMode ? 'bg-black/10 text-black' : 'bg-white/10 text-white/70') : (lightMode ? 'bg-black/5 text-black/40' : 'bg-white/10 text-white/40')}`}>{activeOrders.length}</span>}
             </button>
             <button onClick={() => setActiveTab('ready')}
               className={`px-5 py-2.5 rounded-xl text-sm font-black transition-all ${activeTab === 'ready' ? (lightMode ? 'bg-black text-white' : 'bg-white/[0.1] text-white') : (lightMode ? 'text-black/50 hover:text-black' : 'text-white/35 hover:text-white/60')}`}>
               {t.kitchen_ready||'Hazır'}
               {readyOrders.length > 0 && <span className={`ml-2 px-2 py-0.5 rounded-full text-xs font-black ${activeTab === 'ready' ? (lightMode ? 'bg-black/10 text-black' : 'bg-emerald-500/20 text-emerald-400') : (lightMode ? 'bg-black/5 text-black/40' : 'bg-white/10 text-white/40')}`}>{readyOrders.length}</span>}
              </button>
            </div>

            {/* Station Filter */}
            <div className={`flex rounded-2xl p-1 ${lightMode ? 'bg-black/5 border border-black/10' : 'bg-white/[0.04] border border-white/[0.07]'}`}>
              {['all', 'grill', 'pizza', 'bar', 'dessert'].map(station => (
                <button key={station} onClick={() => setStationFilter(station)}
                  className={`px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all ${stationFilter === station ? (lightMode ? 'bg-black text-white' : 'bg-white/10 text-white') : (lightMode ? 'text-black/50 hover:text-black' : 'text-white/35 hover:text-white/60')}`}>
                  {station === 'all' ? 'Hamısı' : station === 'grill' ? 'Şirə' : station === 'pizza' ? 'Pizza' : station === 'bar' ? 'Bar' : 'Şirniyyat'}
                </button>
              ))}
            </div>
        </div>
      </header>

      {/* ── Smart Queue ── */}
      {activeTab === 'active' && groupedQueue.length > 0 && (
        <div className="mb-4 bg-white/[0.025] border border-white/[0.06] rounded-xl px-4 py-3">
          <div className="flex items-center gap-1.5 mb-2.5">
            <BarChart2 size={12} className="text-white/30" />
            <span className="text-[10px] font-black text-white/30 uppercase tracking-widest">Queue</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {groupedQueue.map(g => (
              <div key={g.product_name} className="flex items-center gap-2 bg-white/[0.04] border border-white/[0.06] rounded-xl px-3 py-2">
                {g.image_url && <div className="w-7 h-7 rounded-lg overflow-hidden flex-shrink-0"><img src={g.image_url} alt="" className="w-full h-full object-cover" /></div>}
                <div>
                  <p className="text-white/60 text-[10px] font-semibold leading-tight">{g.product_name}</p>
                   <p className={`text-sm font-black leading-tight ${lightMode ? 'text-black' : 'text-white'}`}>
                    {g.totalPending}×
                    <span className="text-white/30 text-[9px] font-normal ml-1">{g.tables.sort((a,b)=>a-b).join(', ')}</span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <UpcomingReservations />

      {/* ── Empty state ── */}
      {display.length === 0 && (
        <div className="flex flex-col items-center justify-center h-[50vh] gap-3">
          <div className="w-14 h-14 rounded-2xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-center">
            <Utensils size={22} className="text-white/15" />
          </div>
          <p className="text-white/25 text-sm">{activeTab === 'active' ? (t.kitchen_no_active || 'Aktiv sifariş yoxdur') : (t.kitchen_no_ready || 'Hazır sifariş yoxdur')}</p>
        </div>
      )}

      {/* ── Order cards / Map ── */}
      {viewMode === 'cards' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3 items-start">
          {display.map(renderOrderCard)}
        </div>
      ) : (
        <TableMapView orders={display} tables={kitchenTables} />
      )}

      <KitchenToaster />

      {/* ── Undo toast ── */}
      <AnimatePresence>
        {recentAction && (
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 300, damping: 28 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-5 py-3.5 rounded-2xl bg-[#1a1a1a] border border-white/15 shadow-2xl backdrop-blur-xl"
          >
            <span className="text-white/70 text-sm font-medium">{recentAction.label}</span>
            <button
              onClick={handleUndo}
              className={`px-3.5 py-1.5 rounded-xl text-sm font-black transition-all ${lightMode ? 'bg-black text-white hover:bg-gray-800' : 'bg-white text-black hover:bg-gray-200'}`}
            >↩ Geri qaytar</button>
            <button
              onClick={() => { setRecentAction(null); if (undoTimer.current) clearTimeout(undoTimer.current); }}
              className="w-6 h-6 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/30 hover:text-white/60 transition-all text-xs"
            >×</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
