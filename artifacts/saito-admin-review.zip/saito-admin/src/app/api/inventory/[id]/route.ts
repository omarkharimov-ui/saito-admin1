import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { validateAuth } from '@/lib/api-auth';

function svc() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await validateAuth();
  if (!auth.authenticated) {
    return NextResponse.json({ error: auth.error }, { status: auth.status });
  }

  try {
    const { id } = await params;
    const body = await req.json();
    const supabase = svc();

    const { name, unit, critical_limit, cold_waste_percentage, supplier_id } = body;

    // Get current ingredient to detect supplier change
    const { data: current } = await supabase
      .from('ingredients')
      .select('supplier_id')
      .eq('id', id)
      .single();

    if (!current) {
      return NextResponse.json({ error: 'Ingredient not found' }, { status: 404 });
    }

    // If supplier changed, log the old supplier's prices so they don't affect future calculations
    if (supplier_id && current.supplier_id !== supplier_id) {
      const { data: logs } = await supabase
        .from('inventory_logs')
        .select('cost_per_unit, created_at')
        .eq('ingredient_id', id)
        .eq('type', 'stock_in')
        .order('created_at', { ascending: false });

      if (logs && logs.length > 0) {
        const lastCost = logs[0].cost_per_unit;
        await supabase.from('audit_logs').insert({
          table_name: 'ingredients',
          record_id: id,
          action: 'supplier_changed',
          old_data: { supplier_id: current.supplier_id, last_cost: lastCost },
          new_data: { supplier_id: supplier_id },
        });
      }
    }

    const updates: Record<string, any> = {};
    if (name !== undefined) updates.name = name;
    if (unit !== undefined) updates.unit = unit;
    if (critical_limit !== undefined) updates.critical_limit = critical_limit;
    if (cold_waste_percentage !== undefined) updates.cold_waste_percentage = cold_waste_percentage;
    if (supplier_id !== undefined) updates.supplier_id = supplier_id === '' ? null : supplier_id;

    const { data, error } = await supabase
      .from('ingredients')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json(data);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await validateAuth();
  if (!auth.authenticated) {
    return NextResponse.json({ error: auth.error }, { status: auth.status });
  }

  try {
    const { id } = await params;
    const supabase = svc();

    const { data: recipes } = await supabase
      .from('recipes')
      .select('id')
      .eq('ingredient_id', id)
      .limit(1);

    if (recipes && recipes.length > 0) {
      return NextResponse.json(
        { error: 'Bu inqredient reseptdə istifadə olunur. Əvvəlcə reseptdən silin.' },
        { status: 409 }
      );
    }

    // Delete inventory logs first (foreign key)
    await supabase.from('inventory_logs').delete().eq('ingredient_id', id);

    const { error } = await supabase.from('ingredients').delete().eq('id', id);

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
