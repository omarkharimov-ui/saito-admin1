'use client';

import { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Sun, Moon, X, Calendar, Users } from 'lucide-react';
import { useTheme } from '@/lib/theme/ThemeContext';
import { usePos } from './hooks/usePos';
import { TableCard } from './components/TableCard';
import { ActionSheet } from './components/ActionSheet';
import { ProductGrid } from './components/ProductGrid';
import { CartPanel } from './components/CartPanel';
import { ModifierSheet } from './components/ModifierSheet';
import ReservedTableModal from './components/ReservedTableModal';
import { LiquidDropdown } from '@/components/ui/LiquidDropdown';
import { toast } from '@/lib/toast';
import { printReceipt, getReceiptSettings, printReservation } from '@/lib/print/PrintService';
import { apiFetch } from '@/lib/api-fetch';
import ReceiptPreview from '@/app/admin/shared/ReceiptPreview';
import type { PosProduct, LossItem } from './types/shared';

interface PosReceipt {
  tableNumber: number | string;
  orderId: string;
  items: { product_name: string; quantity: number; total_price: number }[];
  subtotal: number;
  discount: number;
  discountName?: string | null;
  tip: number;
  total: number;
  paymentMethod: string;
  cashAmount?: number;
  cardAmount?: number;
}

export default function POSPage() {
  const { lightMode, setLightMode } = useTheme();
  const pos = usePos();
  const router = useRouter();
   
  const [selectedFloor, setSelectedFloor] = useState<string | null>(null);
  const [actionSheetOpen, setActionSheetOpen] = useState(false);
  const [actionSheetTable, setActionSheetTable] = useState<any>(null);
  
  const [mergeMode, setMergeMode] = useState(false);
  const [selectedForMerge, setSelectedForMerge] = useState<number[]>([]);
  
  const [transferMode, setTransferMode] = useState(false);
  const [transferSource, setTransferSource] = useState<number | null>(null);
  const [transferTarget, setTransferTarget] = useState<number | null>(null);
  const [transferConfirm, setTransferConfirm] = useState(false);
  const [reservationArrival, setReservationArrival] = useState<{ table_number: number; reservation_id: string | null; name: string | null; guests: number; phone?: string | null; time?: string | null; is_vip?: boolean | null } | null>(null);

  const [unmergeMode, setUnmergeMode] = useState(false);
  const [selectedForUnmerge, setSelectedForUnmerge] = useState<number[]>([]);

  const [lastUndo, setLastUndo] = useState<any>(null);
  const [cleanMode, setCleanMode] = useState(false);
  const [rushMode, setRushMode] = useState(false);
  const [paymentView, setPaymentView] = useState(false);
  const [receiptView, setReceiptView] = useState<PosReceipt | null>(null);

  const [modalProduct, setModalProduct] = useState<{ product: PosProduct; variants: any[] } | null>(null);

  // Reservation → pre-order handoff: the reservations page navigates here with
  // ?resId=&tableIds=&guestName= and also writes a localStorage context. When
  // present we enter reservation mode: auto-select the target table, link the
  // cart/order to the reservation, and show a "Bron Et" (Reserve) action.
  const searchParams = useSearchParams();
  const [reservationMode, setReservationMode] = useState(false);
  const [reservationId, setReservationId] = useState<string | null>(null);
  const [reservationGuest, setReservationGuest] = useState<string | null>(null);

  useEffect(() => {
    const resId = searchParams.get('resId') || searchParams.get('reservation_id');
    const tableIds = (searchParams.get('tableIds') || '').split(',').filter(Boolean);
    const guestName = searchParams.get('guestName') || '';
    let ctx: any = null;
    try { ctx = JSON.parse(localStorage.getItem('saito_pos_preorder_context') || 'null'); } catch { ctx = null; }
    // Consume the localStorage handoff exactly once so a stale context from a
    // previous "Öncədən Sifariş" click can't auto-open a table on every later
    // POS visit.
    if (ctx) localStorage.removeItem('saito_pos_preorder_context');

    const finalResId = resId || ctx?.resId;
    const finalTableIds = tableIds.length ? tableIds : (ctx?.tableIds || []);
    const finalGuest = guestName || ctx?.guestName || '';

    if (!finalResId || finalTableIds.length === 0) return;

    setReservationMode(true);
    setReservationId(finalResId);
    setReservationGuest(finalGuest || null);

    // Auto-select the first target table once table data is loaded.
    const trySelect = () => {
      const allTables = (pos.floors || []).flatMap((f: any) => f.tables || []);
      const target = allTables.find((t: any) => finalTableIds.includes(t.id));
      if (target) {
        pos.selectTable(target, { allowReserved: true });
        return true;
      }
      return false;
    };
    if (!trySelect()) {
      const id = setInterval(() => { if (trySelect()) clearInterval(id); }, 300);
      return () => clearInterval(id);
    }
  }, [searchParams, pos.floors]);

  // Stamp the active cart with the reservation link so placeOrder forwards it.
  useEffect(() => {
    if (!reservationMode || !reservationId) return;
    if (pos.cart && pos.cart.table_number && pos.cart.reservation_id !== reservationId) {
      pos.setCart({ ...pos.cart, reservation_id: reservationId, customer_name: pos.cart.customer_name || reservationGuest || undefined });
    }
  }, [reservationMode, reservationId, reservationGuest, pos.cart, pos.setCart]);

  const handleRecordLoss = async (items: LossItem[], reason: string) => {
    const res = await apiFetch('/api/stock/loss', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items, reason }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Loss recording failed');
    }
  };

  const handleProductTap = (product: PosProduct) => {
    const variants = pos.variantsByProduct[product.id] || [];
    if (variants.length > 0) {
      setModalProduct({ product, variants });
    } else {
      pos.addToCart(product);
    }
  };

  const handleOpenPayment = () => setPaymentView(true);
  const handleBackFromPayment = () => setPaymentView(false);

  const handlePaymentMethodSelect = async (method: 'cash' | 'card') => {
    if (!actionSheetTable) return;
    const tableNumbers = actionSheetGroup
      ? [actionSheetTable.table_number, ...actionSheetGroup.children.map((c: any) => c.table_number)]
      : [actionSheetTable.table_number];

    toast.loading('Ödəniş işlənir...', { id: 'action-toast' });
    try {
      const ordersRes = await apiFetch('/api/orders');
      if (!ordersRes.ok) throw new Error('Failed to fetch orders');
      const ordersData = await ordersRes.json();
      const activeOrders = (ordersData.orders || []).filter((o: any) => 
        tableNumbers.includes(o.table_number) && 
        !['paid', 'cancelled', 'closed'].includes(o.status)
      );
      
      if (activeOrders.length === 0) {
        toast.error('Aktiv sifariş tapılmadı', { id: 'action-toast' });
        return;
      }

      const failedOrders: string[] = [];
      for (const activeOrder of activeOrders) {
        const total = activeOrder.total_amount || 0;
        const cashAmount = method === 'cash' ? total : 0;
        const cardAmount = method === 'card' ? total : 0;

        const res = await apiFetch('/api/orders/pay', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            order_id: activeOrder.id,
            payment_method: method,
            cash_amount: cashAmount,
            card_amount: cardAmount,
            tip_amount: 0,
            campaign_id: activeOrder.campaign_id || undefined,
            discount_amount: activeOrder.discount_amount || 0,
            discount_type: activeOrder.discount_type || 'fixed',
          }),
        });

        if (!res.ok) {
          const err = await res.json();
          failedOrders.push(activeOrder.id);
          console.error(`Payment failed for order ${activeOrder.id}:`, err);
        }
      }

      if (failedOrders.length > 0) {
        toast.error(`${failedOrders.length} sifariş ödənilərkən xəta baş verdi. Yenidən cəhd edin.`, { id: 'action-toast' });
        return;
      } else {
        toast.success('Bütün sifarişlər ödənildi', { id: 'action-toast' });
      }

      setPaymentView(false);
      setActionSheetOpen(false);
      pos.fetchData();

      // Build an on-screen receipt so the operator actually SEES what was paid
      // (previously the POS only printed silently, or did nothing).
      const tableNum = actionSheetTable?.table_number ?? activeOrders[0]?.table_number ?? '-';
      const receiptItems: { product_name: string; quantity: number; total_price: number }[] = [];
      let subtotal = 0;
      let discount = 0;
      let tip = 0;
      let total = 0;
      for (const activeOrder of activeOrders) {
        for (const item of (activeOrder.order_items || [])) {
          receiptItems.push({
            product_name: item.product_name || item.products?.name_az || item.products?.name_en || 'Məhsul',
            quantity: item.quantity || 1,
            total_price: Number(item.total_price || item.unit_price * item.quantity || 0),
          });
          subtotal += Number(item.total_price || item.unit_price * item.quantity || 0);
        }
        discount += Number(activeOrder.discount_amount) || 0;
        tip += Number(activeOrder.tip_amount) || 0;
        total += Number(activeOrder.total_amount) || 0;
      }
      setReceiptView({
        tableNumber: tableNum,
        orderId: activeOrders.map((o: any) => o.id).join(','),
        items: receiptItems,
        subtotal,
        discount,
        discountName: activeOrders[0]?.campaigns?.name,
        tip,
        total,
        paymentMethod: method,
        cashAmount: method === 'cash' ? total : 0,
        cardAmount: method === 'card' ? total : 0,
      });

      const settings = await getReceiptSettings();
      if (settings.autoPrintReceipt) {
        for (const activeOrder of activeOrders) {
          const items = (activeOrder.order_items || []).map((item: any) => ({
            name: item.product_name || item.products?.name_az || item.products?.name_en || 'Məhsul',
            quantity: item.quantity || 1,
            price: Number(item.total_price || item.price || 0),
          }));
          await printReceipt({
            restaurantName: settings.restaurantName,
            address: settings.address,
            receiptTitle: settings.receiptTitle,
            currency: settings.receiptCurrency,
            serviceFeePct: settings.serviceFeePct,
            showServiceFee: settings.showServiceFee,
            footerText: settings.footerText,
            tableNumber: activeOrder.table_number,
            orderId: activeOrder.id,
            items,
            subtotal: Number(activeOrder.total_amount) || 0,
            discount: Number(activeOrder.discount_amount) || 0,
            discountName: activeOrder.campaigns?.name,
            tip: 0,
            total: Number(activeOrder.total_amount) || 0,
            paymentMethod: method,
            cashAmount: method === 'cash' ? Number(activeOrder.total_amount) || 0 : 0,
            cardAmount: method === 'card' ? Number(activeOrder.total_amount) || 0 : 0,
            date: new Date().toISOString(),
            time: new Date().toISOString(),
            paperWidth: settings.paperWidth,
            copies: settings.copies,
          });
        }
      }
    } catch (e: any) {
      toast.error(e.message || 'Ödəniş xətası');
    }
  };

  const handleSplitConfirm = async (split: { cash: string; card: string }) => {
    if (!actionSheetTable) return;
    const cash = parseFloat(split.cash) || 0;
    const card = parseFloat(split.card) || 0;
    const total = actionSheetTable.total_amount || 0;
    if (Math.abs((cash + card) - total) > 0.01) {
      toast.error('Məbləğlər ümumi ilə uyğun deyil', { id: 'action-toast' });
      return;
    }
    const tableNumbers = actionSheetGroup
      ? [actionSheetTable.table_number, ...actionSheetGroup.children.map((c: any) => c.table_number)]
      : [actionSheetTable.table_number];
    toast.loading('Ödəniş işlənir...', { id: 'action-toast' });
    try {
      const ordersRes = await apiFetch('/api/orders');
      if (!ordersRes.ok) throw new Error('Failed to fetch orders');
      const ordersData = await ordersRes.json();
      const activeOrders = (ordersData.orders || []).filter((o: any) => 
        tableNumbers.includes(o.table_number) && 
        !['paid', 'cancelled', 'closed'].includes(o.status)
      );
      const failedOrders: string[] = [];
      const orderCount = activeOrders.length;
      const baseCash = Math.floor((cash / orderCount) * 100) / 100;
      const baseCard = Math.floor((card / orderCount) * 100) / 100;
      const cashRemainder = Math.round((cash - baseCash * orderCount) * 100) / 100;
      const cardRemainder = Math.round((card - baseCard * orderCount) * 100) / 100;
      for (let i = 0; i < orderCount; i++) {
        const isLast = i === orderCount - 1;
        const orderCash = isLast ? baseCash + cashRemainder : baseCash;
        const orderCard = isLast ? baseCard + cardRemainder : baseCard;
        const activeOrder = activeOrders[i];
        const res = await apiFetch('/api/orders/pay', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            order_id: activeOrder.id,
            payment_method: 'split',
            cash_amount: orderCash,
            card_amount: orderCard,
            tip_amount: 0,
            campaign_id: activeOrder.campaign_id || undefined,
            discount_amount: activeOrder.discount_amount || 0,
            discount_type: activeOrder.discount_type || 'fixed',
          }),
        });
        if (!res.ok) {
          const err = await res.json();
          failedOrders.push(activeOrder.id);
          console.error(`Split payment failed for order ${activeOrder.id}:`, err);
        }
      }

      if (failedOrders.length > 0) {
        toast.error(`${failedOrders.length} sifariş ödənilərkən xəta baş verdi.`, { id: 'action-toast' });
        return;
      } else {
        toast.success('Bölünmüş ödəniş tamamlandı', { id: 'action-toast' });
      }

      setPaymentView(false);
      setActionSheetOpen(false);
      pos.fetchData();

      const settings = await getReceiptSettings();
      if (settings.autoPrintReceipt) {
        for (const activeOrder of activeOrders) {
          const items = (activeOrder.order_items || []).map((item: any) => ({
            name: item.product_name || item.products?.name_az || item.products?.name_en || 'Məhsul',
            quantity: item.quantity || 1,
            price: Number(item.total_price || item.price || 0),
          }));
          await printReceipt({
            restaurantName: settings.restaurantName,
            address: settings.address,
            receiptTitle: settings.receiptTitle,
            currency: settings.receiptCurrency,
            serviceFeePct: settings.serviceFeePct,
            showServiceFee: settings.showServiceFee,
            footerText: settings.footerText,
            tableNumber: activeOrder.table_number,
            orderId: activeOrder.id,
            items,
            subtotal: Number(activeOrder.total_amount) || 0,
            discount: Number(activeOrder.discount_amount) || 0,
            discountName: activeOrder.campaigns?.name,
            tip: 0,
            total: Number(activeOrder.total_amount) || 0,
            paymentMethod: 'split',
            cashAmount: cash / activeOrders.length,
            cardAmount: card / activeOrders.length,
            date: new Date().toISOString(),
            time: new Date().toISOString(),
            paperWidth: settings.paperWidth,
            copies: settings.copies,
          });
        }
      }
    } catch (e: any) {
      toast.error(e.message || 'Ödəniş xətası');
    }
  };

  const handleDismissGroup = async () => {
    if (!actionSheetTable) return;
    const group = actionSheetGroup;
    const numbers = [actionSheetTable.table_number, ...(group?.children?.map((c: any) => c.table_number) || [])];
    toast.loading('Qrup boşaldılır...', { id: 'action-toast' });
    for (const num of numbers) {
      await pos.dismissTable(num);
    }
    setActionSheetOpen(false);
    pos.fetchData();
    toast.success('Qrup boşaldıldı', { id: 'action-toast' });
  };

  const activeFloor = selectedFloor 
    ? pos.floors.find((f: any) => f.name === selectedFloor) 
    : pos.floors[0];

  const tableGroupInfo = useMemo(() => {
    const info: Record<number, { groupNum: number; children: number[] }> = {};
    if (activeFloor?.merged_groups) {
      activeFloor.merged_groups.forEach((g: any, idx: number) => {
        info[g.parent.table_number] = {
          groupNum: idx + 1,
          children: g.children?.map((c: any) => c.table_number) || []
        };
      });
    }
    return info;
  }, [activeFloor?.merged_groups]);

  const visibleTables = useMemo(() => {
    if (!activeFloor?.tables) return [];
    return activeFloor.tables.filter((table: any) => {
      const isChild = table.parent_table_number && table.table_number !== table.parent_table_number;
      return !isChild;
    });
  }, [activeFloor?.tables]);

  const handleTableTap = (table: any) => {
    if (table.status === 'reserved' && !reservationMode) {
      setReservationArrival({
        table_number: table.table_number,
        reservation_id: table.reservation_id || null,
        name: table.reservation_name || null,
        guests: table.guest_count || 0,
        phone: table.reservation_phone || null,
        time: table.reservation_time || null,
        is_vip: table.is_vip || false,
      });
      return;
    }

    if (mergeMode) {
      if (selectedForMerge.includes(table.table_number)) {
        setSelectedForMerge(p => p.filter(n => n !== table.table_number));
      } else {
        setSelectedForMerge(p => [...p, table.table_number]);
      }
      return;
    }

    if (transferMode) {
      if (!transferSource) {
        const t = table;
        if (!t || t.status === 'empty') {
          toast.error('Boş masadan köçürmə edə bilməzsiniz');
          return;
        }
        setTransferSource(table.table_number);
        toast(`Mənbə: Masa ${table.table_number}. İndi hədəf seçin.`);
      } else if (table.table_number === transferSource) {
        toast.error('Eyni masanı seçdiz');
      } else if (table.status !== 'empty') {
        toast.error('Yalnız boş masaya köçürə bilərsiniz');
      } else {
        setTransferTarget(table.table_number);
        setTransferConfirm(true);
      }
      return;
    }

    pos.selectTable(table);
  };

  const handleConfirmTransfer = async (targetTable?: number) => {
    if (!transferSource || !targetTable) return;
    try {
      const res = await apiFetch('/api/orders/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from_table: transferSource,
          to_table: targetTable,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setLastUndo({ 
          action: 'transfer', 
          data: data.undo, 
          message: `Masa ${transferSource} → ${targetTable}`,
          timestamp: Date.now()
        });
        toast.success('Masa köçürüldü');
        setTimeout(() => setLastUndo(null), 5000);
        setTransferMode(false);
        setTransferSource(null);
        setTransferTarget(null);
        // Refresh the floor so the moved table reflects new state, then make
        // sure the open cart (if any) follows the table. If the user had the
        // SOURCE table open, reopen the TARGET so the cart is rebuilt from the
        // transferred order instead of appearing lost on an now-empty table.
        await pos.fetchData();
        const allTables = (pos.floors || []).flatMap((f: any) => f.tables || []);
        const openedSource = pos.selectedTable && pos.selectedTable.table_number === transferSource;
        if (openedSource) {
          const target = allTables.find((t: any) => t.table_number === targetTable);
          if (target) pos.selectTable(target);
        }
      } else {
        toast.error(data.error || 'Köçürmə uğursuz oldu');
        setTransferMode(false);
        setTransferSource(null);
        setTransferTarget(null);
      }
    } catch (e: any) {
      toast.error(e.message || 'Köçürmə xətası');
      setTransferMode(false);
      setTransferSource(null);
      setTransferTarget(null);
    }
  };

  const handleCancelTransfer = () => {
    setTransferMode(false);
    setTransferSource(null);
    setTransferTarget(null);
  };

  const handleGuestArrived = async (table: { table_number: number; reservation_id: string | null; name: string | null; guests: number }) => {
    const resId = table.reservation_id;
    setReservationArrival(null);
    if (!resId) {
      toast.error('Rezervasiya ID tapılmadı');
      return;
    }
    try {
      const res = await apiFetch('/api/reservations/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reservation_id: resId, status: 'checked_in' }),
      });
      if (res.ok) {
        toast.success('Qonaq gəldi — masa açıldı');
        pos.fetchData();
        setTimeout(() => {
          const allTables = (pos.floors || []).flatMap((f: any) => f.tables || []);
          const opened = allTables.find((t: any) => t.table_number === table.table_number);
          if (opened) pos.selectTable(opened, { allowReserved: true });
        }, 400);
      } else {
        const data = await res.json();
        toast.error(data.error || 'Qonaq gəlmədi');
      }
    } catch (e: any) {
      toast.error(e.message || 'Xəta');
    }
  };

  const handleUndo = async () => {
    if (!lastUndo || !lastUndo.data) return;
    // Transfer uses its own DELETE endpoint; merge/unmerge go through the
    // generic undo route (performUndo) which knows how to reverse each action.
    if (lastUndo.action === 'transfer') {
      try {
        const res = await apiFetch('/api/orders/transfer', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            from_table: lastUndo.data.from_table,
            to_table: lastUndo.data.to_table,
            orders: lastUndo.data.orders,
            table: lastUndo.data.table,
          }),
        });
        const data = await res.json();
        if (res.ok) {
          toast.success('Köçürmə geri alındı');
          setLastUndo(null);
          pos.fetchData();
        } else {
          toast.error(data.error || 'Geri alınmadı');
        }
      } catch (e: any) {
        toast.error(e.message || 'Geri alma xətası');
      }
      return;
    }
    await pos.performUndo();
  };

  const handleUnmerge = async () => {
    if (!actionSheetTable) return;
    if (selectedForUnmerge.length === 0) {
      toast.error('Zəhmət olmasa ən azı bir masa seçin', { id: 'action-toast' });
      return;
    }
    try {
      const res = await apiFetch('/api/orders/unmerge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ primary_table_number: actionSheetTable.table_number, child_table_numbers: selectedForUnmerge }),
      });
      const result = res.ok ? await res.json() : { error: (await res.json()).error || 'Xəta' };
      if (res.ok) {
        toast.success('Masalar ayrıldı', { id: 'action-toast' });
        setUnmergeMode(false);
        setSelectedForUnmerge([]);
        setActionSheetOpen(false);
        pos.fetchData();
      } else {
        toast.error(result.error || 'Ayırma uğursuz oldu', { id: 'action-toast' });
      }
    } catch (e: any) {
      toast.error(e.message || 'Ayırma xətası', { id: 'action-toast' });
    }
  };

  const actionSheetGroup = activeFloor?.merged_groups?.find((g: any) => 
    g.parent.table_number === actionSheetTable?.table_number
  );

  const handleOpenAction = (table: any) => {
    const parentNum = table.parent_table_number || table.table_number;
    const parent = activeFloor?.tables?.find((t: any) => t.table_number === parentNum) || table;
    setActionSheetTable(parent);
    setActionSheetOpen(true);
  };

  return (
    <div className="flex-1 min-h-0 w-full flex flex-col bg-[var(--theme-bg)] text-[var(--theme-text)] overflow-hidden">
      {pos.loading ? (
        <div className="flex-1 min-h-0 relative overflow-hidden">
          <div className="h-full flex flex-col p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="w-24 h-8 bg-white/10 rounded-lg animate-pulse" />
              <div className="flex items-center gap-3">
                <div className="w-24 h-8 bg-white/10 rounded-full animate-pulse" />
                <div className="w-24 h-8 bg-white/10 rounded-full animate-pulse" />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              <div className="grid grid-cols-4 gap-4">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div key={i} className="w-full aspect-[4/5] rounded-[2rem] bg-white/5 border border-white/5 animate-pulse" />
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 min-h-0 relative overflow-hidden">
          <AnimatePresence mode="wait">
            {pos.activeView === 'floor' && (
                <div key="floor" className="h-full flex flex-col p-6">
                {!cleanMode && (
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ type: "spring", stiffness: 400, damping: 30 }}>
                    <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <h1 className="text-3xl font-black tracking-tighter">POS</h1>
                  {pos.floors.length > 1 && (
                    <LiquidDropdown 
                      options={pos.floors.map((f: any) => ({ id: f.name, label: f.name }))} 
                      activeId={activeFloor?.name} 
                      onChange={setSelectedFloor} 
                    />
                  )}
                </div>
                 <div className="flex items-center gap-3">
                     <button
                       onClick={() => router.push('/admin/reservations')}
                       className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/5 border border-white/10 text-xs font-black uppercase tracking-wider hover:bg-white/10 transition-all"
                       title="Rezervasiyalar"
                     >
                       <Calendar size={16} />
                       <span className="hidden sm:inline">Rezervasiyalar</span>
                     </button>
                     <button
                       onClick={async () => {
                         const tableNum = prompt('Masa nömrəsi:');
                         if (!tableNum) return;
                         const guests = prompt('Qonaq sayı:', '1');
                         if (!guests) return;
                         try {
                           const res = await apiFetch('/api/reservations/walk-in', {
                             method: 'POST',
                             headers: { 'Content-Type': 'application/json' },
                             body: JSON.stringify({ table_number: Number(tableNum), guests: Number(guests) }),
                           });
                           if (res.ok) {
                             toast.success(`Masa ${tableNum} — walk-in`);
                             pos.fetchData();
                           } else {
                             const err = await res.json();
                             toast.error(err.error || 'Walk-in uğursuz');
                           }
                         } catch {
                           toast.error('Xəta');
                         }
                       }}
                       className="flex items-center gap-2 px-3 py-2 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-black uppercase tracking-wider hover:bg-amber-500/20 transition-all"
                       title="Walk In"
                     >
                       <span>+</span>
                       <span className="hidden sm:inline">Walk In</span>
                     </button>
                     <button
                       onClick={async () => {
                         const res = await apiFetch('/api/waitlist');
                         const list = res.ok ? await res.json() : [];
                         const selected = prompt('Gələn qonaq adı:\n\n' + list.map((e: any, i: number) => `${i+1}. ${e.name} (${e.guests} nəfər)`).join('\n'));
                         if (!selected) return;
                         const idx = parseInt(selected) - 1;
                         const entry = list[idx];
                         if (!entry) return;
                         const tableNum = prompt('Masa nömrəsi:');
                         if (!tableNum) return;
                         try {
                           const seatRes = await apiFetch('/api/waitlist/seat', {
                             method: 'POST',
                             headers: { 'Content-Type': 'application/json' },
                             body: JSON.stringify({ waitlist_id: entry.id, table_number: Number(tableNum) }),
                           });
                           if (seatRes.ok) {
                             toast.success(`Waitlist → Masa ${tableNum}`);
                             pos.fetchData();
                           } else {
                             const err = await seatRes.json();
                             toast.error(err.error || 'Seat failed');
                           }
                         } catch {
                           toast.error('Xəta');
                         }
                       }}
                       className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/5 border border-white/10 text-xs font-black uppercase tracking-wider hover:bg-white/10 transition-all"
                       title="Waitlist"
                     >
                       <Users size={16} />
                       <span className="hidden sm:inline">Waitlist</span>
                     </button>
                     <div className="flex items-center gap-1 bg-white/5 rounded-full p-1">
                      <button 
                        onClick={() => { setMergeMode(false); setTransferMode(false); }}
                        className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider transition-all ${!mergeMode && !transferMode ? 'bg-white text-black' : 'text-white/50 hover:text-white'}`}
                      >
                        Normal
                      </button>
                      <button 
                        onClick={() => { setMergeMode(true); setTransferMode(false); setSelectedForMerge([]); }}
                        className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider transition-all ${mergeMode ? 'bg-blue-500 text-white' : 'text-white/50 hover:text-white'}`}
                      >
                        Birleştir
                      </button>
                     <button 
                       onClick={() => {
                         setMergeMode(false);
                         setTransferMode(true);
                         setTransferSource(null);
                         setTransferTarget(null);
                         setTransferConfirm(false);
                         if (transferSource && transferTarget) setTransferConfirm(true);
                       }}
                       className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider transition-all ${transferMode ? 'bg-emerald-500 text-white' : 'text-white/50 hover:text-white'}`}
                     >
                        Köçür
                     </button>
                   </div>
                   {transferMode && (
                     <div className="flex items-center gap-2">
                       <div className="px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-wider">
                         {transferSource ? `Mənbə: Masa ${transferSource}` : 'Mənbə seçin'}
                       </div>
                       <button onClick={() => { setTransferMode(false); setTransferSource(null); setTransferTarget(null); setTransferConfirm(false); }} className="px-3 py-1.5 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-black uppercase tracking-wider hover:bg-rose-500/20 transition-all">
                         Ləğv
                       </button>
                     </div>
                   )}
                   <button 
                     onClick={() => setLightMode(!lightMode)} 
                     className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/5 border border-white/10 text-xs font-black uppercase tracking-wider hover:bg-white/10 transition-all"
                   >
                     {lightMode ? <Sun size={16} /> : <Moon size={16} />}
                     <span className="hidden sm:inline">{lightMode ? 'Aydın' : 'Qaranlıq'}</span>
                   </button>
                    <button 
                      onClick={() => {
                        if (!document.fullscreenElement) {
                          document.documentElement.requestFullscreen().catch(() => {});
                        } else {
                          document.exitFullscreen();
                        }
                        setCleanMode(!cleanMode);
                      }}
                      className={`p-3 rounded-full border transition-all ${cleanMode ? 'bg-gold text-black border-gold' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}
                      title="Tam Ekran / Sadə Rejim"
                    >
                      {cleanMode ? (
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/></svg>
                      ) : (
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" />
                        </svg>
                      )}
                    </button>
                 </div>
                </div>
              </motion.div>
               )}

                {reservationArrival && (
                  <ReservedTableModal
                    open={!!reservationArrival}
                    onClose={() => setReservationArrival(null)}
                    table={{
                      table_number: reservationArrival.table_number,
                      reservation_id: reservationArrival.reservation_id,
                      reservation_name: reservationArrival.name,
                      reservation_phone: reservationArrival.phone,
                      reservation_time: reservationArrival.time,
                      guest_count: reservationArrival.guests,
                      status: 'reserved',
                      is_vip: reservationArrival.is_vip,
                    }}
                    onGuestArrived={() => handleGuestArrived(reservationArrival)}
                    onEditReservation={() => {
                      setReservationArrival(null);
                      if (reservationArrival.reservation_id) {
                        router.push(`/admin/reservations?edit=${reservationArrival.reservation_id}`);
                      }
                    }}
                    onMoveTable={() => {
                      setReservationArrival(null);
                      toast.info('Masa dəyişmə funksiyası tezliklə əlavə olunacaq');
                    }}
                    onMergeTable={() => {
                      setReservationArrival(null);
                      toast.info('Masa birləşdirmə funksiyası tezliklə əlavə olunacaq');
                    }}
                    onCancelReservation={() => {
                      setReservationArrival(null);
                      if (reservationArrival.reservation_id) {
                        apiFetch('/api/reservations/status', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ reservation_id: reservationArrival.reservation_id, status: 'cancelled' }),
                        }).then(res => {
                          if (res.ok) {
                            toast.success('Rezervasiya ləğv edildi');
                            pos.fetchData();
                          } else {
                            toast.error('Ləğv edilə bilmədi');
                          }
                        });
                      }
                    }}
                    onMarkNoShow={() => {
                      setReservationArrival(null);
                      if (reservationArrival.reservation_id) {
                        apiFetch('/api/reservations/status', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ reservation_id: reservationArrival.reservation_id, status: 'no_show' }),
                        }).then(res => {
                          if (res.ok) {
                            toast.success('No Show qeyd edildi');
                            pos.fetchData();
                          } else {
                            toast.error('No Show edilə bilmədi');
                          }
                        });
                      }
                    }}
                    onPrintReservation={async () => {
                      setReservationArrival(null);
                      if (!reservationArrival?.reservation_id) return;
                      try {
                        const settings = await getReceiptSettings();
                        await printReservation({
                          restaurantName: settings.restaurantName,
                          address: settings.address,
                          receiptTitle: 'REZERVASİYA BİLETİ',
                          receiptCurrency: settings.receiptCurrency,
                          serviceFeePct: settings.serviceFeePct,
                          showServiceFee: false,
                          footerText: settings.footerText,
                          tableNumber: reservationArrival.table_number,
                          reservationId: reservationArrival.reservation_id,
                          guestName: reservationArrival.name || '',
                          phone: reservationArrival.phone || '',
                          guests: reservationArrival.guests || 0,
                          time: reservationArrival.time || '',
                          isVip: reservationArrival.is_vip || false,
                          paperWidth: settings.paperWidth,
                          copies: settings.copies,
                        });
                        toast.success('Bilet çap edildi');
                      } catch (e: any) {
                        toast.error(e.message || 'Çap xətası');
                      }
                    }}
                  />
                )}

               {cleanMode && (
                <button
                  onClick={() => setCleanMode(false)}
                  className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-6 py-3 bg-black/80 text-white text-xs font-black rounded-full border border-white/10 hover:bg-black transition-all"
                  title="Sadə rejimi bağla"
                >
                  ✕ Sadə rejimi bağla
                </button>
              )}
              {transferConfirm && transferSource && transferTarget && (
                <motion.div
                  initial={{ opacity: 0, y: 100 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 100 }}
                  className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-center p-4 pointer-events-none"
                >
                  <div className="pointer-events-auto w-full max-w-md bg-white text-black rounded-2xl shadow-2xl border border-white/20 p-5">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-600 mb-1">Köçürmə Təsdiqi</p>
                        <p className="text-sm font-bold">Masa {transferSource} → Masa {transferTarget}</p>
                      </div>
                      <button onClick={() => { setTransferConfirm(false); setTransferTarget(null); }} className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-500 hover:bg-zinc-200 transition-all">
                        <X size={16} />
                      </button>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => { setTransferConfirm(false); setTransferMode(false); setTransferSource(null); setTransferTarget(null); }} className="flex-1 py-4 rounded-2xl border border-zinc-200 text-zinc-600 text-xs font-black hover:bg-zinc-50 transition-all">Ləğv</button>
                      <button onClick={() => { handleConfirmTransfer(transferTarget); setTransferConfirm(false); }} className="flex-1 py-4 rounded-2xl bg-emerald-500 text-white text-xs font-black hover:bg-emerald-600 transition-all">Təsdiqlə</button>
                    </div>
                  </div>
                </motion.div>
              )}
  
                <div className="flex-1 overflow-y-auto">
                <div className="grid grid-cols-4 gap-4">
                  {visibleTables?.map((table: any) => {
                    const groupInfo = tableGroupInfo[table.table_number];
                    const isGroup = groupInfo && groupInfo.children.length > 0;
                    
                    return (
                      <motion.div
                        key={table.table_number}
                        layout
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ type: "spring", stiffness: 350, damping: 30 }}
                        className="col-span-1"
                      >
                      <TableCard 
                        table={table}
                        onTap={() => handleTableTap(table)}
                        onAction={() => handleOpenAction(table)}
                        isSelected={selectedForMerge.includes(table.table_number)}
                        selectionMode={mergeMode || transferMode}
                        isTransferSource={transferSource === table.table_number}
                        isTransferTarget={transferTarget === table.table_number}
                        groupNumber={groupInfo?.groupNum}
                        mergedChildNumbers={groupInfo?.children}
                        isMergedChild={false}
                        kitchenStatus={table.kitchen_status}
                      />
                      </motion.div>
                    );
                  })}
                </div>
               </div>
            </div>
          )}

          {pos.activeView === 'order' && pos.selectedTable && (
            <div key="order" className="h-full w-full flex flex-col md:flex-row overflow-hidden">
               <div className="flex-1 p-6 overflow-hidden">
                  <ProductGrid
                    products={pos.products}
                    categories={pos.categories}
                    combos={pos.combos}
                    onAddProduct={(p) => handleProductTap(p)}
                    onAddCombo={(c) => pos.addComboToCart(c)}
                    cartCounts={(pos.cart?.items ?? []).reduce((acc: Record<string, number>, item: any) => {
                      const id = item.product_id;
                      acc[id] = (acc[id] || 0) + (item.quantity || 0);
                      return acc;
                    }, {})}
                    outOfStock={new Set((pos.products ?? []).filter((p: any) => p.is_in_stock === false || p.is_available === false).map((p: any) => p.id))}
                  />
               </div>
                <div className="w-full md:w-[400px] border-l p-6 bg-black/20 flex flex-col h-full overflow-hidden">
                         <CartPanel 
                           cart={pos.cart} 
                           onPlaceOrder={() => {
                             const autoCampaign = pos.getAutoCampaign(pos.cart);
                             pos.placeOrder(autoCampaign ? { id: autoCampaign.id, type: 'AUTO' } : undefined);
                           }} 
                           onBack={() => pos.setActiveView('floor')}
                           orderButtonStatus={pos.placingOrder ? 'loading' : 'idle'}
                           onUpdateQty={(idx, delta) => pos.updateCartItemQty(idx, delta)}
                           onUpdateGuests={(delta) => pos.updateGuestCount(delta)}
                           onUpdateCustomer={(name) => pos.updateCartCustomer(pos.cart?.customer_id || null, name)}
                           onRecordLoss={handleRecordLoss}
                           onClearDraft={() => pos.clearCart()}
                           mergedChildNumbers={activeFloor?.merged_groups?.find((g: any) => g.parent.table_number === pos.selectedTable?.table_number)?.children?.map((c: any) => c.table_number)}
                           customerId={pos.cart?.customer_id}
                           customerName={pos.cart?.customer_name}
                            isReservationMode={reservationMode}
                            reservationId={reservationId || undefined}
                            guestName={reservationGuest || undefined}
                            guestCountLoading={pos.guestCountLoading}
                            onUpdateItem={(idx, patch) => {
                              if (!pos.cart) return;
                              const newItems = [...pos.cart.items];
                              newItems[idx] = { ...newItems[idx], ...patch };
                              pos.setCart({ ...pos.cart, items: newItems });
                            }}
                          />
               </div>
            </div>
          )}
         </AnimatePresence>
       </div>
       )}
 
        <ActionSheet
         table={actionSheetTable} 
         open={actionSheetOpen} 
         onClose={() => { setActionSheetOpen(false); setUnmergeMode(false); setPaymentView(false); setTransferMode(false); setTransferSource(null); setTransferTarget(null); }} 
         onAddOrder={() => { pos.selectTable(actionSheetTable); setActionSheetOpen(false); }}
         onUnmerge={() => setUnmergeMode(true)}
         onOpenPayment={handleOpenPayment}
         onPaymentMethodSelect={handlePaymentMethodSelect}
         onSplitConfirm={handleSplitConfirm}
         onBackFromPayment={handleBackFromPayment}
         onCancelTable={() => { pos.dismissTable(actionSheetTable.table_number); setActionSheetOpen(false); }}
         onDismissGroup={handleDismissGroup}
         paymentView={paymentView}
         mergeMode={mergeMode}
         mergeParent={selectedForMerge[0]}
         unmergeMode={unmergeMode}
         isMerged={!!actionSheetGroup}
         mergedGroupChildren={actionSheetGroup?.children}
         selectedForMerge={selectedForMerge}
         selectedForUnmerge={selectedForUnmerge}
         onToggleUnmerge={(n) => {
           if (selectedForUnmerge.includes(n)) setSelectedForUnmerge(p => p.filter(x => x !== n));
           else setSelectedForUnmerge(p => [...p, n]);
         }}
         onConfirmUnmerge={handleUnmerge}
         onCancelMode={() => { setMergeMode(false); setTransferMode(false); setUnmergeMode(false); setSelectedForMerge([]); setSelectedForUnmerge([]); setTransferSource(null); setTransferTarget(null); }}
          onConfirmMerge={async () => { 
            const undoResult = await pos.mergeTables(selectedForMerge); 
            if (undoResult) setLastUndo({ ...undoResult, timestamp: Date.now() });
            setTimeout(() => setLastUndo(null), 5000);
            setMergeMode(false); 
            setSelectedForMerge([]); 
          }}
          groupNumber={actionSheetTable ? tableGroupInfo[actionSheetTable.table_number]?.groupNum : undefined}
            customerId={pos.cart?.customer_id}
           customerName={pos.cart?.customer_name}
           onSelectCustomer={(customerId, customerName) => {
             pos.updateCartCustomer(customerId, customerName);
           }}
        />

      <AnimatePresence>
        {lastUndo && (
          <motion.div initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 50, opacity: 0 }} className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[110] flex items-center gap-6 px-8 py-4 rounded-[2rem] bg-zinc-900 text-white shadow-2xl border border-white/10">
            <span className="text-sm font-bold">{lastUndo.message}</span>
            <button onClick={handleUndo} className="px-6 py-2.5 rounded-2xl bg-white text-black text-xs font-black uppercase tracking-widest hover:bg-zinc-200 transition-all active:scale-95">Geri Al</button>
          </motion.div>
        )}
      </AnimatePresence>

      <ModifierSheet
        open={!!modalProduct}
        productName={modalProduct?.product.name || ''}
        productPrice={modalProduct?.product.price || 0}
        variants={modalProduct?.variants || []}
        onClose={() => setModalProduct(null)}
        onConfirm={(_modifiers, notes, variantId) => {
          if (modalProduct) {
            pos.addToCart(modalProduct.product, { variantId: variantId || null, notes });
          }
          setModalProduct(null);
        }}
      />

      <AnimatePresence>
        {receiptView && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[120] flex items-center justify-center bg-black/70 p-4"
            onClick={() => setReceiptView(null)}
          >
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 30, opacity: 0 }}
              className="bg-white rounded-2xl p-4 shadow-2xl max-h-[90vh] overflow-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <ReceiptPreview
                title="SİFARİŞ ÇEKİ"
                tableNumber={receiptView.tableNumber}
                items={receiptView.items}
                showServiceFee={false}
                serviceFeePct={0}
                currency="₼"
                discountAmount={receiptView.discount}
                campaignName={receiptView.discountName || undefined}
              />
              <div className="mt-4 text-center text-[11px] text-zinc-500">
                {receiptView.paymentMethod === 'cash' ? 'Nağd' : receiptView.paymentMethod === 'card' ? 'Kart' : receiptView.paymentMethod}
                {' · '}
                {receiptView.total.toFixed(2)} ₼
              </div>
              <button
                onClick={() => setReceiptView(null)}
                className="mt-4 w-full py-3 rounded-2xl bg-zinc-900 text-white text-xs font-black uppercase tracking-widest hover:bg-zinc-700 transition-all active:scale-95"
              >
                Bağla
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
