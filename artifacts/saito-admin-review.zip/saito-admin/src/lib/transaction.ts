/**
 * PRODUCTION-GRADE TRANSACTIONAL ORDER ENGINE
 * 
 * Ensures all financial operations are:
 * - Atomic: All or nothing
 * - Concurrency-safe: Prevent double spending/booking
 * - Idempotent: Safe to retry
 */

export interface OrderUpdatePayload {
  order_id: string;
  status?: string;
  table_number?: number;
  total_amount?: number;
  guest_count?: number;
  payment_method?: string;
  paid_amount?: number;
  version?: number;
}

/**
 * Order action runner with error logging.
 * Does NOT provide atomicity or rollback — use DB-level RPCs for atomic operations.
 */
export async function runOrderAction<T>(
  actionName: string,
  businessLogic: () => Promise<T>
): Promise<{ success: boolean; data?: T; error?: string }> {
  try {
    const result = await businessLogic();
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

/**
 * LEGACY TRANSACTION WRAPPER (Used by Inventory/Procurement)
 * Maintained for backward compatibility.
 */
export async function withTransaction(
  steps: { name: string; execute: () => Promise<any>; rollback: () => Promise<void> }[]
): Promise<{ success: boolean; results: any[] }> {
  const completedSteps: number[] = [];
  const results: any[] = [];
  
  try {
    for (let i = 0; i < steps.length; i++) {
      const res = await steps[i].execute();
      results.push(res);
      completedSteps.push(i);
    }
    return { success: true, results };
  } catch (error) {
    for (const idx of completedSteps.reverse()) {
      try {
        await steps[idx].rollback();
      } catch (rbError) {
      }
    }
    throw error;
  }
}

/**
 * Transaction Logging (Used by Inventory/Procurement)
 */
export async function createTransactionLog(action: string, status: 'completed' | 'failed' | 'pending', details?: string): Promise<void> {
  try {
    const { supabase } = await import('./supabase');
    await supabase.from('transaction_logs').insert({
      action,
      status,
      details,
      created_at: new Date().toISOString()
    });
  } catch (e) {
    console.error('[TransactionLog] Failed to log:', e);
  }
}

/**
 * Validates table state transitions
 * @deprecated Use tableStatus.ts instead
 */
export { isValidTableTransition, TableStatus } from './tableStatus';
